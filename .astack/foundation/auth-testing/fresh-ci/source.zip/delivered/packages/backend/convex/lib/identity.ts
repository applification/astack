import type { Auth, UserIdentity } from 'convex/server';
import { ConvexError } from 'convex/values';

export function isLoopbackUrl(value: string | undefined): boolean {
  if (value === undefined) return false;
  try {
    const url = new URL(value);
    return (
      (url.protocol === 'http:' || url.protocol === 'https:') &&
      ['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)
    );
  } catch {
    return false;
  }
}

export function localProofEnabled(): boolean {
  if (process.env.ASTACK_PROOF_MODE !== 'local') return false;
  if (!isLoopbackUrl(process.env.CONVEX_SITE_URL)) {
    throw new Error(
      'Local proof authentication requires a loopback Convex deployment.',
    );
  }
  return true;
}

export function emulateEnabled(): boolean {
  if (process.env.ASTACK_AUTH_MODE !== 'emulate') return false;
  const issuer = process.env.WORKOS_EMULATE_URL;
  if (
    !isLoopbackUrl(process.env.CONVEX_SITE_URL) ||
    !issuer ||
    !isLoopbackUrl(issuer) ||
    new URL(issuer).origin !== issuer ||
    new URL(issuer).username ||
    new URL(issuer).password
  )
    throw new Error(
      'WorkOS Emulate is restricted to a local Convex deployment and loopback issuer origin.',
    );
  return true;
}

export function mcpIssuer(): string | undefined {
  return emulateEnabled()
    ? process.env.WORKOS_EMULATE_URL
    : localProofEnabled()
      ? process.env.ASTACK_PROOF_ISSUER
      : process.env.WORKOS_AUTHKIT_DOMAIN;
}

export function isLocalMcpResource(
  site: string | undefined,
  resource: string,
): boolean {
  if (!isLoopbackUrl(site) || !isLoopbackUrl(resource)) return false;
  const url = new URL(resource);
  return (
    url.origin === new URL(site ?? '').origin &&
    url.pathname === '/mcp' &&
    !url.username &&
    !url.password &&
    !url.search &&
    !url.hash
  );
}

export async function requireUser(auth: Auth): Promise<UserIdentity> {
  const identity = await auth.getUserIdentity();
  if (
    identity === null ||
    identity.subject.length === 0 ||
    (!localProofEnabled() && !identity.subject.startsWith('user_'))
  ) {
    throw new ConvexError({
      code: 'UNAUTHENTICATED',
      message: 'Sign in to manage your work items.',
    });
  }
  return identity;
}

export function denyUnavailableItem(): never {
  throw new ConvexError({
    code: 'FORBIDDEN',
    message: 'This work item is unavailable.',
  });
}
