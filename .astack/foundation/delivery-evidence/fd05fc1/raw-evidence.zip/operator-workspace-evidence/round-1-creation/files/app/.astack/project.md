# Work items reference

This disposable reference shares one Convex domain across a React/Vite web app and authenticated MCP Apps endpoint. Its canonical DTO is `id`, `title`, `status`; status is `open` or `done`. Production identity is WorkOS. Local proof uses temporary signed JWTs with distinct web and MCP audiences and no external account.

From this directory use Bun 1.4.x and Node 24.x. Run `bun install --frozen-lockfile`; the prepare script installs the project hook in the enclosing workspace Git repository at `app/.husky/_`. Keep that hook active. This workspace uses its existing Git repository; the app does not contain a second repository.

The feedback commands have distinct scopes:

- `bun run check:quick -- <file...>` runs typed lint on the named files. Without arguments it selects current Git edits, or all handwritten source when the selection is empty.
- `bun run check:affected -- <base-ref>` selects changes against the supplied Git base (default `HEAD`) and includes affected consumers. Shared/configuration changes or uncertain scope select the complete workspace.
- `bun run check:ci` checks formatting, typed lint, all workspace type checks, deterministic tests, MCP UI embedding, the web bundle, and Storybook. It does not establish integration readiness.
- `bun run readiness -- --evidence <directory>` launches an isolated local Convex deployment, Vite web app, Chromium browser, and MCP App host to verify actual behavior. `bun run verify` reaches the same implementation.
- `bun run dev` starts the configured WorkOS product. Follow the environment and origin setup in `README.md`; this live identity route was not configured in the disposable trial.

The direct product control route is `./.codex/skills/astack-work-items/control.ts doctor --json` then `./.codex/skills/astack-work-items/control.ts verify --json --evidence .proof/<run>`. Its [skill](../.codex/skills/astack-work-items/SKILL.md) and [feature map](feature-map/work-items/README.md) describe the mapped user journey. Doctor checks the checkout only and does not certify a live target. Ensure the Node 24 binary is first in the subprocess `PATH`; the initial doctor in this workspace observed Node 22 before that environment correction.

`verify` owns its disposable Convex backend, Vite process and browser. It derives separate free ports, confirms backend and web build identity, drives the user path, independently reads persisted effects, and cleans up. `.proof/<run>/report.json` and screenshots remain; tokens, private signing keys, database state and environment files are excluded from retained evidence and Git. Never point this route at production or a shared local deployment.

The local MCP App host is a real SDK bridge to the running endpoint. Live WorkOS identity and installed ChatGPT OAuth/UI are separate, explicit proof gaps until exercised with authorized test accounts. Do not relabel local results as those host results.

The [foundation setup result](foundation-setup/README.md) retains observed commands, limitations, and selected credential-free evidence. For this disposable local task, the owner authorized local changes and proof and prohibited PR publication, pushing, merging, recursive delegation, and contacting others.
