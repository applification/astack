# Foundation setup result

The candidate `scripts/create-foundation.ts` generated `app/` in the existing workspace Git repository. The generated [scaffold manifest](../scaffold.json) identifies the `convex-workos-mcp-v1` profile, candidate source revision, source digest, and frozen-lock digest. The generated package boundaries, scripts, control skill, and feature map are retained.

## Observed checks

- Bun 1.4.0 installed the frozen lock successfully. A retained repeat install reported no dependency changes and confirmed `app/.husky/_` was active.
- Direct control `--help` and `doctor --json` ran successfully. The initial doctor observed Node 22.14.0 and reported that prerequisite as failed; selecting the installed Node 24.21.0 binary in `PATH` made all four prerequisites pass. No doctor or check requirement was changed.
- `bun run check:ci` passed initially and again under the supported Node 24 environment: formatting, typed lint, five workspace typecheck tasks, tooling type checks, 28 deterministic tests with zero failures, MCP UI embedding, web build, and Storybook build.
- `bun run check:quick -- apps/web/src/work-items.tsx packages/backend/convex/http.ts` passed with those two files selected. `bun run check:affected -- HEAD` selected the complete workspace for the new shared/configuration source and passed lint, type checks, and all 28 tests. The final formatting check passed after adding this profile and evidence.
- The mapped `control.ts verify --json --evidence .proof/foundation-setup/readiness` run passed R1–R8 on an identified disposable backend/web build. Creating through the web was confirmed by an independent authenticated Convex read; web done/reopen and MCP status changes survived independent reads and web reloads. Other-user, anonymous, expired-token, and wrong-audience access was denied. Malformed MCP arguments were rejected. The MCP resource was self-contained.
- The local MCP App bridge applied initial and updated styles, acknowledged teardown, remounted, and changed persisted status. Host observations recorded two mounts, two teardown acknowledgements, four closed owned connections, and no uncaught App errors. Web observations recorded no uncaught JavaScript error.
- Readiness reported complete cleanup. Its JSON report, runtime log, host observations, and two screenshots survived cleanup. Both screenshots were visually inspected.

The retained [supported-toolchain CI log](evidence/check-ci-node24.log), [doctor report](evidence/doctor.json), [install log](evidence/install-frozen.log), and [readiness report](evidence/readiness-initial/report.json) are observations of the named revision plus source digest, including uncommitted source at the time of the initial run. The control CLI and `bun run readiness` call the same project-owned verifier.

## Limits and retained observations

The local issuer uses disposable signed test identities with separate web and MCP audiences. No live WorkOS sign-in, consent, refresh, or organization lifecycle was exercised; these need a configured authorized WorkOS test environment. Installed ChatGPT OAuth, autonomous tool selection, and UI behavior were not exercised. Fresh-agent delivery work was outside this local task.

The build emitted advisory chunk-size warnings, which remain in the CI logs. The local host recorded aborted requests and HTTP 405 browser messages; the protocol check expects 405 for unsupported MCP streaming methods. The lifecycle and persistence assertions passed, and the report does not claim an empty host browser-message log.

Raw run output stays under ignored `.proof/foundation-setup/`. Selected evidence is intentionally retained in this tracked `evidence/` directory, which the existing source-identity helper excludes from source hashing. Reports and text logs are screened for JWTs, Bearer [REDACTED], private keys, and secret assignments before retention. Retained text copies remove trailing horizontal whitespace; original run logs remain in `.proof/`. Temporary keys, tokens, local environment files, and database state are not retained. No shared backend or external account was configured.

## Reproduce locally

From `app/`, with Bun 1.4.x and Node 24.x first in `PATH`:

```sh
bun install --frozen-lockfile
bunx --no-install playwright install chromium
bun run check:ci
./.codex/skills/astack-work-items/control.ts --help
./.codex/skills/astack-work-items/control.ts doctor --json
./.codex/skills/astack-work-items/control.ts verify --json --evidence .proof/my-run
```

Alternatively, `bun run readiness -- --evidence .proof/my-run` invokes the same verifier. Use a new evidence directory for each run and inspect every check and cleanup outcome. The verifier starts and stops only its owned disposable runtime; the recorded loopback URLs are historical run observations.
