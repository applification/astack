# Foundation creation trial

Created `app/` by invoking the supplied candidate's `scripts/create-foundation.ts` with the new app destination. The existing workspace Git repository owns the project. The scaffold profile is `convex-workos-mcp-v1`; its provenance is retained in `app/.astack/scaffold.json` and [the install record](evidence/scaffold-install.json).

The generated project retains React/Vite web and MCP App surfaces, shared UI/domain/config packages, Convex operations and HTTP MCP serving, WorkOS configuration templates, frozen dependencies, strict checks, the executable control skill and its feature map. Only the project profile was expanded with the actual local environment, commands, evidence location and authorization limits. No handwritten backend change was needed.

## Observed checks

| Check                                          | Observation                                                                                                                        | Evidence                                                                                                           |
| ---------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ |
| Frozen install                                 | Passed; 514 packages installed; lock SHA-256 matches scaffold provenance                                                           | [Install](evidence/frozen-install.log), [lock identity](evidence/scaffold-install.json)                            |
| `bun run check:ci`                             | Passed formatting, zero-warning handwritten lint, strict typechecks, 28 tests / 410 assertions, MCP UI, web and Storybook builds   | [Full log](evidence/check-ci.log)                                                                                  |
| `bun run check:quick -- <files...>`            | Passed typed lint for web, backend and control CLI files; this is scoped feedback                                                  | [Log](evidence/quick.log)                                                                                          |
| `bun run check:affected -- HEAD`               | Passed; creation/shared changes selected complete workspace lint/typechecks/tests                                                  | [Log](evidence/affected.log)                                                                                       |
| `bun run enforcement`                          | All 15 cases passed, including detection of deliberately invalid promise, types, accessibility, hooks and portable-package imports | [Report](evidence/enforcement-report.json)                                                                         |
| Direct executable `--help` and `doctor --json` | Passed without global installation; Bun 1.4.0, Node 24.21.0 and frozen installed dependencies                                      | [Help](evidence/control-help.log), [doctor](evidence/doctor-final.json)                                            |
| Generated pre-commit hook                      | Installed as `app/.husky/_`; the foundation commit passed staged preparation, formatting and lint with the hook enabled            | Local commit `391ca62cb55c885a7e23480c0b4e7de8c2351c53`                                                            |
| Mapped control `verify --json --evidence ...`  | R1–R8 passed; G1/G2 explicitly skipped; cleanup complete                                                                           | [Report](evidence/readiness/report.json), [command](evidence/readiness-command.json)                               |
| `bun run readiness --evidence ...`             | Project-script entry point also passed R1–R8 with G1/G2 skipped; cleanup complete                                                  | [Report](evidence/readiness-project-script/report.json), [command](evidence/readiness-project-script-command.json) |

The initial doctor selected Node 22.14.0 from its subprocess PATH and reported that prerequisite as failed. Selecting the already installed Node 24 directory resolved it, as documented in `app/.astack/project.md`; the check was not relaxed. Chromium 153.0.8010.12 launched through the pinned Playwright package. Vite reported advisory bundle-size warnings for the web and Storybook builds; these remain visible in the CI log.

CI ran before the documentation-only project-profile addition. The subsequent scoped/affected checks and enabled commit hook passed. Both readiness entry points ran the committed final app source, identified by:

```text
391ca62cb55c885a7e23480c0b4e7de8c2351c53@sha256-92bcf74a8e87c0dcbe7496004c04f590c42df2c2c27ab28e37fd41a0bb25f6e0
```

## Running behavior and retained proof

The [feature map](../../app/.astack/feature-map/work-items/README.md) describes the journey driven by `./.codex/skills/astack-work-items/control.ts verify` from `app/`. R1 established backend and web build identity. R2 created through the browser and confirmed a fresh authenticated Convex read. R3 drove web done/reopen, observed the same state through MCP, changed it through MCP and reloaded the web. R4 rejected another user's read/mutations. R5 rejected anonymous, web-audience, wrong-audience and expired identities. R6 checked malformed MCP arguments, method handling and the self-contained HTML resource. R7 exercised the local SDK AppBridge host, persisted UI actions, host styling, teardown/remount and closure. R8 observed no uncaught web JavaScript error.

[Web screenshot](evidence/readiness/web-persisted.png) and [MCP App screenshot](evidence/readiness/mcp-app-host.png) were visually inspected. Independent backend reads, rather than screenshots alone, establish persisted effects. Reports retain exact build identities, isolated loopback URLs, disposable test actors, case outcomes and artifacts. The artifact checksum manifest covers retained evidence bytes.

Both readiness runs stopped their owned services and removed disposable fixture state. [Independent cleanup observations](evidence/cleanup-observations.json) check that their web/Convex/MCP ports closed and their evidence survived. Ephemeral tokens, private signing keys, deployment environment files and database state are not retained. Text evidence receives credential-pattern scanning; [sanitization metadata](evidence/sanitization.json) records the broad redaction of a benign test description and normalization of generated log trailing whitespace for Git checks, with before/after hashes.

## Material gaps and scope

- G1: live WorkOS sign-in, redirect/consent, renewal and organization lifecycle were not exercised; this requires a configured authorized test tenant. Disposable signed JWTs prove local identity boundaries only.
- G2: installed ChatGPT OAuth, tool selection and host UI were not exercised. The local AppBridge fixture does not establish installed-host or autonomous agent behavior.
- Full URL-filter/create/delete coverage across every client is outside the retained baseline journey; the map is navigation guidance, not additional acceptance evidence.

The authorized disposable local creation and readiness task is complete. The application and evidence are retained locally. No PR, push, merge, recursive delegation or messages to others were performed. No check was weakened. Trial harnesses and evaluator rubrics were not inspected.
