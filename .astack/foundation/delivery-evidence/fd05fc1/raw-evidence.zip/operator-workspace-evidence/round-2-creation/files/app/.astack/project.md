# Work items reference

This disposable reference shares one Convex domain across a React/Vite web app and authenticated MCP Apps endpoint. Its canonical DTO is `id`, `title`, `status`; status is `open` or `done`. Production identity is WorkOS. Local proof uses temporary signed JWTs with distinct web and MCP audiences and no external account.

From this directory run `bun install --frozen-lockfile`, `bun run typecheck`, `bun run test`, `bun run build` and `bun run verify`. The direct product control route is `./.codex/skills/astack-work-items/control.ts doctor --json` then `./.codex/skills/astack-work-items/control.ts verify --json`. Its tracked feature map is `.astack/feature-map/work-items/README.md`.

`verify` owns its disposable Convex backend, Vite process and browser. It derives separate free ports, confirms backend and web build identity, drives the user path, independently reads persisted effects, and cleans up. `.proof/<run>/report.json` and screenshots remain; tokens, private signing keys, database state and environment files are excluded from retained evidence and Git. Never point this route at production or a shared local deployment.

The local MCP App host is a real SDK bridge to the running endpoint. Live WorkOS identity and installed ChatGPT OAuth/UI are separate, explicit proof gaps until exercised with authorized test accounts. Do not relabel local results as those host results.

## Checks and this local trial

`bun run check:quick -- <files...>` provides typed lint for named files. `bun run check:affected -- <base-ref>` selects changed packages and their consumers, broadening shared/config changes to the workspace. `bun run check:ci` runs formatting, lint, strict typechecks, retained tests and web/MCP UI/Storybook builds. `bun run enforcement` separately verifies that deliberate rule violations are rejected. `bun run readiness` invokes the same disposable integration engine as the control CLI's `verify`; deterministic CI does not establish integration readiness.

This project lives at `app/` inside the existing workspace repository. Its installed hook is `app/.husky/_` and runs the project's staged checks. The owner authorized only a disposable local trial, with local changes and evidence retained; publication, pushes, merges, recursive delegation and contacting others are outside its scope.

The trial uses Bun 1.4.0, Node 24.21.0 and pinned Playwright Chromium. The default subprocess PATH initially selected Node 22.14.0. Select the already installed Node 24 before invoking the commands in this environment:

```sh
export PATH="<host-user>/.nvm/versions/node/v24.21.0/bin:$PATH"
./.codex/skills/astack-work-items/control.ts doctor --json
./.codex/skills/astack-work-items/control.ts verify --json --evidence ../.astack/creation/evidence/readiness
```

The feature map and control skill above describe the verified journey. Retained local check logs, reports and screenshots are under the enclosing repository's `.astack/creation/evidence/`; `.astack/creation/README.md` records observed results and limits. Each readiness report names the commit plus source digest, actors, isolated URLs and cleanup outcome. Screenshots and an independent authenticated read establish different parts of the journey. Local proof uses ephemeral signed identities, not live WorkOS credentials; only the owned disposable processes and state are removed.
