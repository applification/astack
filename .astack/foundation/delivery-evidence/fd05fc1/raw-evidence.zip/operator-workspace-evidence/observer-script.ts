import { createHash } from 'node:crypto';
import { isUtf8 } from 'node:buffer';
import { readFile, readdir, lstat, realpath, mkdir, writeFile } from 'node:fs/promises';
import { join, relative, extname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { redactTrial } from '../../scripts/trials.ts';
import { sourceDigest } from '../../scripts/source-identity.ts';

const foundation = resolve(fileURLToPath(new URL('../..', import.meta.url)));
const output = join(foundation, '.proof/delivery-fd05fc1-repaired');
const retained = join(output, 'operator-workspace-evidence');
const expected = 'fd05fc1b3c2f0f7aafbc638efc37f20f6d5b3105';
const digest = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex');
const clean = (text: string) => redactTrial(text)
  .replace(/<host-user>(?=\/|\b)/g, '<host-user>')
  .replace(/(?:\/private)?\/var\/folders\/[^/\s"'<>]+\/[^/\s"'<>]+\/T(?=\/|\b)/g, '<host-temp>');
const prompt = await readFile(join(output, 'round-2-creation/task/prompt.txt'), 'utf8');
const match = /Invoke the candidate scaffold at (\S+)\/scripts\/create-foundation\.ts/.exec(prompt);
if (!match?.[1]) throw new Error('No candidate scaffold path in owned task prompt.');
const candidate = await realpath(match[1]);
const temporary = resolve(candidate, '..');
if (!/^astack-trials-[A-Za-z0-9]+$/.test(temporary.split('/').at(-1) ?? ''))
  throw new Error('Unexpected owned trial basename.');
const marker = join(candidate, '.astack/candidate-revision');
if ((await readFile(marker, 'utf8')).trim() !== expected) throw new Error('Candidate ownership marker mismatch.');
await mkdir(retained, { recursive: true });
const startedAt = new Date().toISOString();
const scriptSha256 = digest(await readFile(fileURLToPath(import.meta.url)));
const policySha256 = digest(await readFile(join(foundation, 'scripts/trials.ts')));
const stages = new Map<string, any>();
const observer: any = {
  format: 'astack-supplemental-evidence-observer/v1',
  candidate: expected,
  startedAt,
  finishedAt: null,
  pid: process.pid,
  scriptSha256,
  credentialBinaryPolicySha256: policySha256,
  taskPromptSha256: digest(prompt),
  ownedTemporaryBasename: temporary.split('/').at(-1),
  scope: 'Read-only observations of owned stage lifecycle metadata and evidence. No agent steering, project writes, canonical report or score changes. Collection does not establish a delivery pass.',
  pollingMilliseconds: 3000,
  maximumMilliseconds: 2 * 60 * 60_000,
  candidateMarkerVerified: true,
  status: 'running',
  stages: [],
  observations: [],
};
let stopping = false;
process.on('SIGINT', () => { stopping = true; observer.status = 'interrupted'; });
process.on('SIGTERM', () => { stopping = true; observer.status = 'interrupted'; });
async function exists(path: string) {
  try { return await lstat(path); } catch { return undefined; }
}
async function safeWrite(path: string, bytes: Buffer | string) {
  await mkdir(resolve(path, '..'), { recursive: true });
  await writeFile(path, bytes);
}
function blocked(name: string): string | undefined {
  const parts = name.split('/');
  if (parts.some((part) => part.startsWith('.env') || ['node_modules', '.git', '.convex'].includes(part)))
    return 'Environment, dependency, Git or local backend directory excluded without reading contents.';
  if (parts.some((part) => /(?:^|[._-])(?:private(?:[-_]?key)?|credentials?|secrets?)(?:[._-]|$)/i.test(part) || /\.(?:pem|key|p12|pfx)$/i.test(part) || /^id_(?:rsa|ed25519)$/.test(part)))
    return 'Private or credential path excluded without reading contents.';
}
async function capture(workspace: string, stage: any, root: string, observedAt: string) {
  for (const entry of (await readdir(root, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const path = join(root, entry.name), name = relative(workspace, path), reason = blocked(name);
    if (reason || entry.isSymbolicLink()) {
      stage.omissions.set(name, { path: clean(name), reason: reason ?? 'Symlink excluded without following its target.', lastSeenAt: observedAt });
      continue;
    }
    if (entry.isDirectory()) { await capture(workspace, stage, path, observedAt); continue; }
    if (!entry.isFile()) continue;
    let bytes: Buffer;
    try { bytes = await readFile(path); } catch { continue; }
    const originalSha256 = digest(bytes), extension = extname(name).toLowerCase();
    const image = extension === '.png' ? bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
      : extension === '.jpg' || extension === '.jpeg' ? bytes.subarray(0, 3).equals(Buffer.from([255, 216, 255]))
      : extension === '.webp' && bytes.subarray(0, 4).toString('ascii') === 'RIFF' && bytes.subarray(8, 12).toString('ascii') === 'WEBP';
    const unsupported = /\.(?:zip|gz|gzip|bz2|xz|7z|rar|tar|pdf|woff2?|ttf|otf|eot|wasm|db|sqlite|mp[34]|mov|webm|wav)$/i.test(name)
      || !isUtf8(bytes) || /[\u0000-\u0008\u000b\u000c\u000e-\u001a\u001c-\u001f\u007f]/.test(bytes.toString('utf8'));
    if (!image && (['.png', '.jpg', '.jpeg', '.webp'].includes(extension) || unsupported)) {
      stage.omissions.set(name, { path: clean(name), originalSha256, sizeBytes: bytes.length, reason: 'Unsupported binary/compressed artifact or invalid image signature; excluded.', lastSeenAt: observedAt });
      continue;
    }
    const retainedBytes = image ? bytes : Buffer.from(clean(bytes.toString('utf8')));
    const prior = stage.files.get(name);
    const version = {
      observedAt, originalSha256, retainedSha256: digest(retainedBytes), originalBytes: bytes.length,
      retainedBytes: retainedBytes.length, transformed: !retainedBytes.equals(bytes),
      transformations: image ? [] : ['Current credential redaction and personal filesystem-prefix sanitization; changed-byte flag is authoritative.'],
    };
    const record = prior ?? { path: clean(name), sourceProvenance: `<owned-trial>/${stage.name}/${clean(name)}`, firstSeenAt: observedAt, versions: [] };
    record.lastSeenAt = observedAt;
    record.presentAtLastStageObservation = true;
    record.latest = version;
    if (!prior || prior.versions.at(-1)?.originalSha256 !== originalSha256) {
      record.versions.push(version);
      await safeWrite(join(retained, stage.name, 'versions', name, originalSha256), retainedBytes);
      await safeWrite(join(retained, stage.name, 'files', name), retainedBytes);
    }
    stage.files.set(name, record);
  }
}
async function persist() {
  observer.lastObservedAt = new Date().toISOString();
  observer.stages = [];
  for (const [name, stage] of stages) {
    const summary = { name, firstObservedAt: stage.firstObservedAt, lastObservedAt: stage.lastObservedAt, workspacePresent: stage.workspacePresent, capturedFiles: stage.files.size, omittedPaths: stage.omissions.size, lastObservedSource: stage.lastObservedSource, deliveryFinalPresent: stage.deliveryFinalPresent, reviewFinalPresent: stage.reviewFinalPresent };
    observer.stages.push(summary);
    await safeWrite(join(retained, name, 'manifest.json'), JSON.stringify({ format: 'astack-supplemental-stage-evidence/v1', candidate: expected, ...summary, coverage: 'Latest successful read-only snapshots, with all observed file versions retained. This does not claim an atomic workspace snapshot. Missing or changing files can be observed on subsequent polls.', files: [...stage.files.values()].sort((a, b) => a.path.localeCompare(b.path)), omissions: [...stage.omissions.values()].sort((a, b) => a.path.localeCompare(b.path)) }, null, 2) + '\n');
  }
  await safeWrite(join(retained, 'observer.json'), JSON.stringify(observer, null, 2) + '\n');
}
console.log(JSON.stringify({ observer: 'started', pid: process.pid, candidate: expected, scriptSha256 }));
try {
  const deadline = Date.now() + observer.maximumMilliseconds;
  let lastProgress = '';
  while (!stopping && Date.now() < deadline) {
    if (!(await exists(temporary))) { observer.status = 'owned-workspace-removed'; break; }
    if ((await readFile(marker, 'utf8')).trim() !== expected) { observer.status = 'ownership-marker-changed'; break; }
    for (const name of Array.from({ length: 2 }, (_, index) => ['creation', 'feature', 'bug'].map((kind) => `round-${index + 1}-${kind}`)).flat()) {
      const workspace = join(temporary, name), stat = await exists(workspace);
      const prior = stages.get(name);
      if (!stat?.isDirectory() || stat.isSymbolicLink()) { if (prior) prior.workspacePresent = false; continue; }
      const observedAt = new Date().toISOString();
      const stage = prior ?? { name, firstObservedAt: observedAt, files: new Map(), omissions: new Map() };
      stage.lastObservedAt = observedAt; stage.workspacePresent = true;
      for (const file of stage.files.values()) file.presentAtLastStageObservation = false;
      stages.set(name, stage);
      const roots = ['.astack', '.proof', 'evidence', ...(name.endsWith('creation') ? ['app/.astack', 'app/.proof', 'app/evidence'] : [])];
      for (const local of roots) {
        const root = join(workspace, local), rootStat = await exists(root);
        if (rootStat?.isDirectory() && !rootStat.isSymbolicLink()) {
          try { await capture(workspace, stage, root, observedAt); } catch (error) { observer.observations.push({ at: observedAt, stage: name, observation: clean(String(error)) }); }
        }
      }
      const project = name.endsWith('creation') ? join(workspace, 'app') : workspace;
      try { stage.lastObservedSource = { sha256: await sourceDigest(project), observedAt, method: 'Current sourceDigest, excluding credentials/generated/proof/evidence paths; no source writes.' }; } catch {}
      stage.deliveryFinalPresent = Boolean(await exists(join(output, name, 'task/final.json')));
      stage.reviewFinalPresent = Boolean(await exists(join(output, name, 'review/final.json')));
    }
    await persist();
    const progress = JSON.stringify(observer.stages.map((x: any) => ({ name: x.name, files: x.capturedFiles, deliveryFinal: x.deliveryFinalPresent, reviewFinal: x.reviewFinalPresent })));
    if (progress !== lastProgress) { console.log(progress); lastProgress = progress; }
    await Bun.sleep(3000);
  }
  if (observer.status === 'running') observer.status = stopping ? 'interrupted' : 'bounded-two-hour-stop';
} catch (error) {
  observer.status = 'observer-error';
  observer.observations.push({ at: new Date().toISOString(), observation: clean(String(error)) });
} finally {
  observer.finishedAt = new Date().toISOString();
  await persist();
  console.log(JSON.stringify({ observer: 'finished', status: observer.status, stages: observer.stages }));
}
