# Create and change work items

In the web app, open **Work items**, fill **Title**, and select **Add work item**. The new item appears in the authenticated list. **Mark done** and **Reopen** change its status. URL status filtering limits the list to the chosen state.

Select the row action **Edit <current title>** to open **Edit work item**. Change the **Title** textbox and select **Save changes**, or discard the draft with **Cancel** or Escape. Empty, whitespace-only and over-160-character titles are rejected. Successful edits trim surrounding whitespace and preserve status and ownership.

The MCP tools `work_items_list`, `work_items_create`, `work_items_set_status`, `work_items_update_title({id,title})`, and `work_items_delete` reach the same domain. Title edits use Convex `workItems:updateTitle({id,title})`, which rechecks ownership and title validation. The MCP App opens the `ui://foundation/work-items.html` resource in a compatible host.

Run `./.codex/skills/astack-work-items/control.ts verify --json`. It creates through the actual web, checks a fresh Convex read, changes status through the running MCP endpoint, reloads the web and renders the resource through AppBridge. A visible row supports presentation; the independent authenticated query supports persistence. It also checks anonymous, expired, wrong-audience and other-user denials.

Run `bun scripts/readiness.ts --task-profile title-edit --evidence .proof/title-edit` for those baseline checks plus web-to-Convex/MCP and MCP-to-Convex/web title persistence, empty-title validation, and other-user edit denials.

Prerequisites are installed frozen dependencies and Chromium (`bunx playwright install chromium` if unavailable). The local proof issuer is allowed only in the disposable loopback environment. It verifies ownership and authentication boundaries; it does not verify live WorkOS login or the installed ChatGPT host.
