# Create and change work items

In the web app, open **Work items**, fill **Title**, and select **Add work item**. The new item appears in the authenticated list. **Mark done** and **Reopen** change its status. URL status filtering limits the list to the chosen state.

To edit an existing item, select its **Edit** row action (accessible name **Edit <current title>**). The **Edit work item** dialog pre-fills **Title**; **Save changes** persists the title and **Cancel** or Escape discards the draft. Titles are trimmed and must contain 1–160 characters. Validation and save errors retain the draft.

The MCP tools `work_items_list`, `work_items_create`, `work_items_set_status`, `work_items_update_title({id,title})`, and `work_items_delete` reach the same domain. Title editing calls Convex `workItems:updateTitle({id,title})`, which rechecks authentication and ownership and returns the item with its status preserved. Empty, whitespace-only, or oversized titles return `INVALID_TITLE`; unavailable or other-user items return `FORBIDDEN`. The MCP App opens the `ui://foundation/work-items.html` resource in a compatible host.

Run `./.codex/skills/astack-work-items/control.ts verify --json`. It creates through the actual web, checks a fresh Convex read, changes status through the running MCP endpoint, reloads the web and renders the resource through AppBridge. A visible row supports presentation; the independent authenticated query supports persistence. It also checks anonymous, expired, wrong-audience and other-user denials.

Prerequisites are installed frozen dependencies and Chromium (`bunx playwright install chromium` if unavailable). The local proof issuer is allowed only in the disposable loopback environment. It verifies ownership and authentication boundaries; it does not verify live WorkOS login or the installed ChatGPT host.

For title-edit proof plus the baseline journey, run `bun run readiness -- --task-profile title-edit --evidence .proof/title-edit`. This also checks web edits through independent Convex/MCP reads, MCP edits through Convex and a reloaded web page, empty-title validation, and another user's denied edit on both APIs.
