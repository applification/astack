import { createHash } from 'node:crypto';
import { isUtf8 } from 'node:buffer';
import { stripVTControlCharacters } from 'node:util';
import { readFile, readdir, lstat, realpath, mkdir, writeFile } from 'node:fs/promises';
import { join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { redactTrial } from '../../scripts/trials.ts';

const foundation = resolve(fileURLToPath(new URL('../..', import.meta.url)));
const output = join(foundation, '.proof/delivery-fd05fc1-repaired');
const retained = join(output, 'operator-terminal-evidence');
const expected = 'fd05fc1b3c2f0f7aafbc638efc37f20f6d5b3105';
const digest = (bytes: Buffer | string) => createHash('sha256').update(bytes).digest('hex');
const sanitize = (text: string) => redactTrial(text)
  .replace(/<host-user>(?=\/|\b)/g, '<host-user>')
  .replace(/(?:\/private)?\/var\/folders\/[^/\s"'<>]+\/[^/\s"'<>]+\/T(?=\/|\b)/g, '<host-temp>');
const prompt = await readFile(join(output, 'round-2-creation/task/prompt.txt'), 'utf8');
const match = /Invoke the candidate scaffold at (\S+)\/scripts\/create-foundation\.ts/.exec(prompt);
if (!match?.[1]) throw new Error('No candidate path in owned trial prompt.');
const candidate = await realpath(match[1]), temporary = resolve(candidate, '..');
if (!/^astack-trials-[A-Za-z0-9]+$/.test(temporary.split('/').at(-1) ?? '')) throw new Error('Unexpected temporary basename.');
const marker = join(candidate, '.astack/candidate-revision');
if ((await readFile(marker, 'utf8')).trim() !== expected) throw new Error('Candidate ownership mismatch.');
await mkdir(retained, { recursive: true });
const startedAt = new Date().toISOString();
const observer: any = {
  format: 'astack-supplemental-terminal-observer/v1', candidate: expected, startedAt, finishedAt: null,
  pid: process.pid, scriptSha256: digest(await readFile(fileURLToPath(import.meta.url))),
  credentialPolicySha256: digest(await readFile(join(foundation, 'scripts/trials.ts'))),
  taskPromptSha256: digest(prompt), ownedTemporaryBasename: temporary.split('/').at(-1),
  candidateMarkerVerified: true, pollingMilliseconds: 3000, maximumMilliseconds: 2 * 60 * 60_000,
  scope: 'Separate read-only collection of UTF-8 .log files under stage lifecycle/evidence folders. Terminal normalization is explicit; artifacts are not claimed verbatim. Original observer omissions, agent workspaces and canonical scores remain unchanged.',
  normalization: 'Reject NUL, invalid UTF-8 and binary/archive signatures; strip Node VT control sequences before credential redaction; preserve LF/TAB and render other remaining ASCII controls as literal hexadecimal escapes; sanitize known personal filesystem prefixes.',
  status: 'running', stages: [], observations: [],
};
const stages = new Map<string, any>();
let stopping = false;
process.on('SIGINT', () => { stopping = true; observer.status = 'interrupted'; });
process.on('SIGTERM', () => { stopping = true; observer.status = 'interrupted'; });
async function exists(path: string) { try { return await lstat(path); } catch { return undefined; } }
async function write(path: string, bytes: Buffer | string) { await mkdir(resolve(path, '..'), { recursive: true }); await writeFile(path, bytes); }
function exclusion(name: string) {
  const parts = name.split('/');
  if (parts.some((part) => part.startsWith('.env') || ['node_modules', '.git', '.convex'].includes(part))) return 'environment-dependency-git-backend';
  if (parts.some((part) => /(?:^|[._-])(?:private(?:[-_]?key)?|credentials?|secrets?)(?:[._-]|$)/i.test(part) || /\.(?:pem|key|p12|pfx)$/i.test(part) || /^id_(?:rsa|ed25519)$/.test(part))) return 'private-credential';
}
function binarySignature(bytes: Buffer) {
  const prefix = bytes.subarray(0, 16);
  return prefix.subarray(0, 2).equals(Buffer.from([0x50, 0x4b]))
    || prefix.subarray(0, 2).equals(Buffer.from([0x1f, 0x8b]))
    || prefix.subarray(0, 6).equals(Buffer.from([0xfd, 0x37, 0x7a, 0x58, 0x5a, 0]))
    || prefix.subarray(0, 6).equals(Buffer.from([0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c]))
    || prefix.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
    || prefix.subarray(0, 3).equals(Buffer.from([255, 216, 255]))
    || /^(?:Rar!|BZh|%PDF-|wOFF|wOF2|SQLite format)/.test(prefix.toString('ascii'))
    || prefix.subarray(0, 4).equals(Buffer.from([0, 97, 115, 109]))
    || (prefix.subarray(0, 4).toString('ascii') === 'RIFF')
    || bytes.subarray(257, 262).toString('ascii') === 'ustar';
}
async function capture(workspace: string, root: string, stage: any, at: string) {
  for (const entry of (await readdir(root, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const path = join(root, entry.name), name = relative(workspace, path), excluded = exclusion(name);
    if (excluded || entry.isSymbolicLink()) {
      stage.exclusionCounts[excluded ?? 'symlink'] = (stage.exclusionCounts[excluded ?? 'symlink'] ?? 0) + 1;
      continue;
    }
    if (entry.isDirectory()) { await capture(workspace, path, stage, at); continue; }
    if (!entry.isFile() || !name.toLowerCase().endsWith('.log')) continue;
    let bytes: Buffer; try { bytes = await readFile(path); } catch { continue; }
    const originalSha256 = digest(bytes);
    if (!isUtf8(bytes) || bytes.includes(0) || binarySignature(bytes)) {
      stage.omissions.set(name, { path: sanitize(name), originalSha256, sizeBytes: bytes.length, lastObservedAt: at, reason: 'Invalid UTF-8, NUL or unsupported binary/archive signature; no normalization/copy.' });
      continue;
    }
    const original = bytes.toString('utf8'), vtStripped = stripVTControlCharacters(original);
    let renderedControls = 0;
    const visible = vtStripped.replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, (value) => {
      renderedControls++; return `\\x${value.charCodeAt(0).toString(16).padStart(2, '0')}`;
    });
    const sanitized = sanitize(visible), retainedBytes = Buffer.from(sanitized);
    const prior = stage.files.get(name), latest = {
      observedAt: at, originalSha256, retainedSha256: digest(retainedBytes), originalBytes: bytes.length, retainedBytes: retainedBytes.length,
      transformed: !bytes.equals(retainedBytes), terminalSequencesStripped: vtStripped !== original, renderedAsciiControlCount: renderedControls,
      credentialOrPersonalPathRedactionApplied: sanitized !== visible,
      byteClaim: 'Explicitly normalized terminal text; original hash identifies observed bytes, retained hash identifies exported bytes.',
    };
    const record = prior ?? { path: sanitize(name), sourceProvenance: `<owned-trial>/${stage.name}/${sanitize(name)}`, firstSeenAt: at, versions: [] };
    record.lastSeenAt = at; record.latest = latest; record.presentAtLastStageObservation = true;
    if (!prior || prior.versions.at(-1)?.originalSha256 !== originalSha256) {
      record.versions.push(latest);
      await write(join(retained, stage.name, 'versions', name, originalSha256), retainedBytes);
      await write(join(retained, stage.name, 'files', name), retainedBytes);
    }
    stage.files.set(name, record);
  }
}
async function persist() {
  observer.lastObservedAt = new Date().toISOString(); observer.stages = [];
  for (const [name, stage] of stages) {
    const summary = { name, firstObservedAt: stage.firstObservedAt, lastObservedAt: stage.lastObservedAt, workspacePresentAtLastObservation: stage.workspacePresent, capturedLogCount: stage.files.size, omittedLogCount: stage.omissions.size, lastTraversalExclusionCounts: stage.exclusionCounts };
    observer.stages.push(summary);
    await write(join(retained, name, 'manifest.json'), JSON.stringify({ format: 'astack-supplemental-terminal-stage/v1', candidate: expected, ...summary, normalization: observer.normalization, files: [...stage.files.values()].sort((a, b) => a.path.localeCompare(b.path)), omissions: [...stage.omissions.values()].sort((a, b) => a.path.localeCompare(b.path)) }, null, 2) + '\n');
  }
  await write(join(retained, 'observer.json'), JSON.stringify(observer, null, 2) + '\n');
}
console.log(JSON.stringify({ observer: 'started', pid: process.pid, candidate: expected, scriptSha256: observer.scriptSha256 }));
try {
  const deadline = Date.now() + observer.maximumMilliseconds; let lastProgress = '';
  while (!stopping && Date.now() < deadline) {
    if (!(await exists(temporary))) { observer.status = 'owned-workspace-removed'; break; }
    if ((await readFile(marker, 'utf8')).trim() !== expected) { observer.status = 'ownership-marker-changed'; break; }
    for (const name of Array.from({ length: 2 }, (_, index) => ['creation', 'feature', 'bug'].map((kind) => `round-${index + 1}-${kind}`)).flat()) {
      const workspace = join(temporary, name), stat = await exists(workspace), prior = stages.get(name);
      if (!stat?.isDirectory() || stat.isSymbolicLink()) { if (prior) prior.workspacePresent = false; continue; }
      const at = new Date().toISOString(), stage = prior ?? { name, firstObservedAt: at, files: new Map(), omissions: new Map() };
      stage.workspacePresent = true; stage.lastObservedAt = at; stage.exclusionCounts = {};
      for (const file of stage.files.values()) file.presentAtLastStageObservation = false;
      stages.set(name, stage);
      const roots = ['.astack', '.proof', 'evidence', ...(name.endsWith('creation') ? ['app/.astack', 'app/.proof', 'app/evidence'] : [])];
      for (const local of roots) {
        const root = join(workspace, local), rootStat = await exists(root);
        if (rootStat?.isDirectory() && !rootStat.isSymbolicLink()) try { await capture(workspace, root, stage, at); }
        catch (error) { observer.observations.push({ at, stage: name, observation: sanitize(String(error)) }); }
      }
    }
    await persist();
    const progress = JSON.stringify(observer.stages.map((x: any) => ({ name: x.name, logs: x.capturedLogCount, omissions: x.omittedLogCount })));
    if (progress !== lastProgress) { console.log(progress); lastProgress = progress; }
    await Bun.sleep(3000);
  }
  if (observer.status === 'running') observer.status = stopping ? 'interrupted' : 'bounded-two-hour-stop';
} catch (error) { observer.status = 'observer-error'; observer.observations.push({ at: new Date().toISOString(), observation: sanitize(String(error)) }); }
finally { observer.finishedAt = new Date().toISOString(); await persist(); console.log(JSON.stringify({ observer: 'finished', status: observer.status, stages: observer.stages })); }
