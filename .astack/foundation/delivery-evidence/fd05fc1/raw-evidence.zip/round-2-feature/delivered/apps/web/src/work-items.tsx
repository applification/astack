import { useEffect, useRef, useState } from 'react';
import { useAuth } from '@workos-inc/authkit-react';
import { useConvexAuth, useMutation, useQuery } from 'convex/react';
import { Link } from '@tanstack/react-router';
import { useForm } from '@tanstack/react-form';
import { api } from '@foundation/backend/api';
import type { Id } from '@foundation/backend/types';
import { z } from 'zod';
import { errorMessage, titleSchema } from '@foundation/domain';
import type { WorkItem } from '@foundation/domain';
import { Button, Input, Notice, WorkItemList, Workspace } from '@foundation/ui';

function LoginButton() {
  const { signIn } = useAuth();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string>();
  async function login() {
    setPending(true);
    setError(undefined);
    try {
      await signIn();
    } catch (failure) {
      setError(errorMessage(failure));
    } finally {
      setPending(false);
    }
  }
  return (
    <>
      <Button
        type="button"
        disabled={pending}
        onClick={() => {
          login().catch((failure: unknown) => {
            setError(errorMessage(failure));
          });
        }}
      >
        {pending ? 'Opening sign in…' : 'Sign in'}
      </Button>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
    </>
  );
}
function CreateForm({
  onCreate,
}: {
  onCreate: (title: string) => Promise<unknown>;
}) {
  const [error, setError] = useState<string>();
  const form = useForm({
    defaultValues: { title: '' },
    validators: { onChange: z.object({ title: titleSchema }) },
    onSubmit: async ({ value }) => {
      setError(undefined);
      try {
        await onCreate(titleSchema.parse(value.title));
        form.reset();
      } catch (failure) {
        setError(errorMessage(failure));
      }
    },
  });
  return (
    <form
      className="create-form"
      onSubmit={(event) => {
        event.preventDefault();
        form.handleSubmit().catch((failure: unknown) => {
          setError(errorMessage(failure));
        });
      }}
    >
      <form.Field name="title">
        {(field) => (
          <div className="field">
            <label htmlFor="title">Title</label>
            <Input
              id="title"
              name="title"
              value={field.state.value}
              onBlur={field.handleBlur}
              onChange={(event) => {
                field.handleChange(event.target.value);
              }}
              aria-describedby={
                field.state.meta.errors.length ? 'title-error' : undefined
              }
              aria-invalid={field.state.meta.errors.length > 0}
            />
            {field.state.meta.isTouched &&
              field.state.meta.errors.length > 0 && (
                <p id="title-error" className="error">
                  {field.state.meta.errors
                    .map((issue) => issue?.message)
                    .join(', ')}
                </p>
              )}
          </div>
        )}
      </form.Field>
      <form.Subscribe selector={(state) => state.isSubmitting}>
        {(pending) => (
          <Button type="submit" disabled={pending}>
            {pending ? 'Adding…' : 'Add work item'}
          </Button>
        )}
      </form.Subscribe>
      {error && (
        <p role="alert" className="error">
          {error}
        </p>
      )}
    </form>
  );
}
function EditTitleDialog({
  item,
  onSave,
  onClose,
}: {
  item: WorkItem;
  onSave: (title: string) => Promise<unknown>;
  onClose: () => void;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [error, setError] = useState<string>();
  const schema = z.object({ title: titleSchema });
  const form = useForm({
    defaultValues: { title: item.title },
    validators: { onChange: schema, onSubmit: schema },
    onSubmit: async ({ value }) => {
      setError(undefined);
      try {
        await onSave(titleSchema.parse(value.title));
        onClose();
      } catch (failure) {
        setError(errorMessage(failure));
      }
    },
  });
  useEffect(() => {
    const dialog = dialogRef.current;
    dialog?.showModal();
    return () => dialog?.close();
  }, []);
  return (
    <dialog
      ref={dialogRef}
      className="edit-dialog"
      aria-labelledby="edit-work-item-heading"
      onCancel={(event) => {
        event.preventDefault();
        if (!form.state.isSubmitting) onClose();
      }}
    >
      <h2 id="edit-work-item-heading">Edit work item</h2>
      <form
        noValidate
        onSubmit={(event) => {
          event.preventDefault();
          form.handleSubmit().catch((failure: unknown) => {
            setError(errorMessage(failure));
          });
        }}
      >
        <form.Field name="title">
          {(field) => (
            <div className="field">
              <label htmlFor="edit-title">Title</label>
              <form.Subscribe selector={(state) => state.isSubmitting}>
                {(pending) => (
                  <Input
                    id="edit-title"
                    name="title"
                    value={field.state.value}
                    disabled={pending}
                    onBlur={field.handleBlur}
                    onChange={(event) => {
                      field.handleChange(event.target.value);
                    }}
                    aria-invalid={field.state.meta.errors.length > 0}
                    aria-describedby={
                      field.state.meta.errors.length
                        ? 'edit-title-error'
                        : undefined
                    }
                  />
                )}
              </form.Subscribe>
              {field.state.meta.errors.length > 0 && (
                <p id="edit-title-error" role="alert" className="error">
                  {field.state.meta.errors
                    .map((issue) => issue?.message)
                    .join(', ')}
                </p>
              )}
            </div>
          )}
        </form.Field>
        {error && (
          <p role="alert" className="error">
            {error}
          </p>
        )}
        <form.Subscribe
          selector={(state) => [state.isSubmitting, state.canSubmit] as const}
        >
          {([pending, canSubmit]) => (
            <div className="dialog-actions">
              <Button
                type="button"
                variant="secondary"
                disabled={pending}
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={pending || !canSubmit}>
                {pending ? 'Saving…' : 'Save changes'}
              </Button>
            </div>
          )}
        </form.Subscribe>
      </form>
    </dialog>
  );
}
export function WorkItemsFeature({
  status,
}: {
  status: 'all' | 'open' | 'done';
}) {
  const { isLoading, isAuthenticated } = useConvexAuth();
  const items = useQuery(api.workItems.list, isAuthenticated ? {} : 'skip');
  const create = useMutation(api.workItems.create);
  const changeStatus = useMutation(api.workItems.setStatus);
  const updateTitle = useMutation(api.workItems.updateTitle);
  const [editingItem, setEditingItem] = useState<WorkItem>();
  const [pendingId, setPendingId] = useState<string>();
  const saving = useRef(false);
  const [error, setError] = useState<string>();
  async function toggle(item: WorkItem) {
    if (saving.current) return;
    saving.current = true;
    setPendingId(item.id);
    setError(undefined);
    try {
      await changeStatus({
        // The portable DTO has a string ID; Convex's v.id validator checks it at the boundary.
        id: item.id as Id<'workItems'>,
        status: item.status === 'open' ? 'done' : 'open',
      });
    } catch (failure) {
      setError(errorMessage(failure));
    } finally {
      saving.current = false;
      setPendingId(undefined);
    }
  }
  return (
    <Workspace>
      {isLoading ? (
        <Notice>Checking your session…</Notice>
      ) : !isAuthenticated ? (
        <>
          <Notice>Sign in to access your private work items.</Notice>
          <LoginButton />
        </>
      ) : (
        <>
          <CreateForm onCreate={(title) => create({ title })} />
          <nav className="filters" aria-label="Work item filters">
            {(['all', 'open', 'done'] as const).map((filter) => (
              <Link
                to="/"
                search={{ status: filter }}
                key={filter}
                aria-current={filter === status ? 'page' : undefined}
              >
                {filter === 'all'
                  ? 'All items'
                  : filter === 'open'
                    ? 'Open'
                    : 'Done'}
              </Link>
            ))}
          </nav>
          {error && (
            <p role="alert" className="error">
              {error}
            </p>
          )}
          {items ? (
            <WorkItemList
              items={items.filter(
                (item) => status === 'all' || item.status === status,
              )}
              {...(pendingId ? { pendingId } : {})}
              onStatusChange={(item) => {
                toggle(item).catch((failure: unknown) => {
                  setError(errorMessage(failure));
                });
              }}
              onEdit={setEditingItem}
            />
          ) : (
            <Notice>Loading work items…</Notice>
          )}
          {editingItem && (
            <EditTitleDialog
              key={editingItem.id}
              item={editingItem}
              onSave={(title) =>
                updateTitle({
                  id: editingItem.id as Id<'workItems'>,
                  title,
                })
              }
              onClose={() => {
                setEditingItem(undefined);
              }}
            />
          )}
        </>
      )}
    </Workspace>
  );
}
