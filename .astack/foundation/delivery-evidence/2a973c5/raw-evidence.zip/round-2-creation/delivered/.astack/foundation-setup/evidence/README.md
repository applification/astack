# Foundation creation evidence

The supported foundation was generated into `app/` with the candidate's `scripts/create-foundation.ts` and retained in the existing enclosing Git repository. The product source tested by both readiness entry points is commit `09f98e566e06261ba465d73c8676ecf408c6f3bb`, with source SHA-256 `5cbe6bf7d8c35d9648d1952c2c3c4e8c6c6cc76f687e0d2077aa84e29b8a9595`. Later retained evidence is excluded by the project's source identity function; [audit.json](audit.json) confirms the current source matches that identity.

## Observed checks

| Check                          | Result and evidence                                                                                                                                                                                                                      |
| ------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Frozen install                 | Passed with Bun 1.4.0; lock SHA-256 matches scaffold provenance. See [install-frozen.log](install-frozen.log) and [audit.json](audit.json).                                                                                              |
| Direct control help and doctor | Executable mode `100755`, command discovery, and every checkout prerequisite passed with Node 24.21.0. See [control-help.log](control-help.log) and [doctor.log](doctor.log).                                                            |
| Deterministic CI               | Formatting, workspace lint/types, 32 retained tests, web/MCP UI bundles, and Storybook build passed. See [check-ci.log](check-ci.log).                                                                                                   |
| Architectural enforcement      | All 15 valid/invalid fixture checks passed and temporary probes were removed. See [enforcement-report.json](enforcement-report.json).                                                                                                    |
| Scoped feedback                | Named web/backend quick checks and the affected workspace checks passed. See [checks.json](checks.json).                                                                                                                                 |
| Package readiness              | `bun run readiness -- --evidence .astack/foundation-setup/evidence/script-readiness` passed R1–R8 with complete cleanup. See [script-readiness/report.json](script-readiness/report.json).                                               |
| Direct control readiness       | `./.codex/skills/astack-work-items/control.ts verify --json --evidence .astack/foundation-setup/evidence/control-readiness` passed R1–R8 with complete cleanup. See [control-readiness/report.json](control-readiness/report.json).      |
| Independent retention audit    | All expected artifacts survived cleanup; all six reported local web/Convex/MCP endpoint ports were closed; the retained text credential scan passed. Web and MCP host screenshots were visually inspected. See [audit.json](audit.json). |
| Existing repository hook       | The foundation source commit ran the installed project hook successfully, including pinned formatting and strict staged lint. No checks were bypassed.                                                                                   |

Both running journeys identified their backend and web build, created through the actual browser, confirmed fresh authenticated Convex reads, changed status across web and MCP, rejected another user's operations and invalid credentials, checked MCP argument/resource contracts, and exercised the local AppBridge host's styles, teardown and remount. The reports contain the exact observations and the disposable loopback URLs used during each run. Those instances have been stopped.

Screenshots are retained in each run directory as `web-persisted.png` and `mcp-app-host.png`; each also retains `mcp-host-observations.json` and redacted `runtime.log`. Command logs have credential redaction and trailing whitespace normalization; reports preserve their observed outcomes.

## First attempts and limits

The first doctor reported Node 22 outside the supported prerequisite; selecting the already installed Node 24 runtime resolved it. The first CI attempt rejected the evidence JSON's formatting. That failure is retained in [check-ci-attempt-1.log](check-ci-attempt-1.log) and [checks-attempt-1.json](checks-attempt-1.json); formatting with the pinned Prettier resolved it. See [toolchain.md](toolchain.md).

G1 remains skipped: live WorkOS sign-in, refresh, consent and organization lifecycle require a configured test tenant and authorized live identities. G2 remains skipped: installed ChatGPT OAuth, native host UI and autonomous tool selection were not exercised. Local signed disposable identities and the local SDK host do not prove those integrations. Storybook was built; no isolated Storybook browser journey was selected. Web and Storybook builds reported bundle-size warnings, with no check failure; performance was not evaluated.

The trial retained the generated code, original frozen lock, project profile, control skill, feature map, contract and evidence locally. It did not publish a PR, push, merge, contact anyone, or run recursive delivery agents. The external trial harness and evaluator rubric were not inspected.
