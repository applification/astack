# Work items reference

This disposable reference shares one Convex domain across a React/Vite web app and authenticated MCP Apps endpoint. Its canonical DTO is `id`, `title`, `status`; status is `open` or `done`. Production identity is WorkOS. Local proof uses temporary signed JWTs with distinct web and MCP audiences and no external account.

From this directory run `bun install --frozen-lockfile`, `bun run typecheck`, `bun run test`, `bun run build` and `bun run verify`. The direct product control route is `./.codex/skills/astack-work-items/control.ts doctor --json` then `./.codex/skills/astack-work-items/control.ts verify --json`. Its tracked feature map is `.astack/feature-map/work-items/README.md`.

## Feedback and readiness commands

Use Bun 1.4.x and Node 24.x; select the supported Node runtime in the invoking shell before installing or running proof. Install Chromium with `bunx --no-install playwright install chromium`.

- `bun run check:quick -- <file...>` prepares the embedded MCP UI and runs typed lint for the named files. Without files it uses Git changes, or all handwritten source when selection is uncertain. It does not prove integrated behavior.
- `bun run check:affected -- <base-ref>` selects changed apps and affected consumers against the Git base. Shared package, tooling, or uncertain scope changes broaden to workspace lint, types, and tests. Use `HEAD` for the current local change.
- `bun run check:ci` checks formatting, workspace coverage, strict lint/types, retained contracts, web and MCP UI bundles, and Storybook build. It is the deterministic gate.
- `bun run enforcement` checks that deliberate invalid fixtures are rejected and valid composition passes. It restores the source and retains `.proof/enforcement/report.json`; it does not establish all semantic architecture or test quality.
- `bun run readiness -- --evidence <directory>` runs the disposable browser, Convex, and MCP integration gate. The direct control CLI's `verify --json --evidence <directory>` invokes the same readiness implementation.

Backend and shared domain changes can affect both web and MCP even when those adapters are unchanged. Shared presentation changes also affect the local MCP App host and web. Evidence for this creation trial is linked from [the foundation setup contract](foundation-setup/behavior-contract.md).

`verify` owns its disposable Convex backend, Vite process and browser. It derives separate free ports, confirms backend and web build identity, drives the user path, independently reads persisted effects, and cleans up. `.proof/<run>/report.json` and screenshots remain; tokens, private signing keys, database state and environment files are excluded from retained evidence and Git. Never point this route at production or a shared local deployment.

The local MCP App host is a real SDK bridge to the running endpoint. Live WorkOS identity and installed ChatGPT OAuth/UI are separate, explicit proof gaps until exercised with authorized test accounts. Do not relabel local results as those host results.

This authorized disposable trial retains its changes and evidence in the existing repository. Publication, PRs, pushes, merges, contacts, and recursive delegation are excluded by the caller.
