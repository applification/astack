# Toolchain resolution

The first read-only control doctor observed Bun 1.4.0, installed dependencies and the frozen lock, but Node v22.14.0 failed the documented Node 24.x prerequisite. No running target was created by that inspection.

An already installed Node v24.21.0 was selected for the trial shell by prepending `<host-user>/.nvm/versions/node/v24.21.0/bin` to that shell's `PATH`. Both `node --version` and a Node subprocess launched by Bun reported v24.21.0. The subsequent doctor reported every prerequisite passing and `ready: true`. This did not change global shell configuration or relax the project prerequisite.

`bunx --no-install playwright install chromium` exited 0; the pinned browser runtime was already available. `doctor.log` contains the passing observation. The first CI attempt rejected the command evidence JSON's formatting; that attempt is retained in `check-ci-attempt-1.log` and `checks-attempt-1.json`. The evidence was formatted with the project's pinned Prettier before the successful CI run.
