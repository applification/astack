# Foundation setup

Create the supported `convex-workos-mcp-v1` foundation in `app/` using the candidate scaffold, keep its frozen Bun lock, and prove the local web, Convex, and MCP paths in the existing Git repository.

## Acceptance

- S1: The generated workspace retains the scaffold provenance, frozen lock, scoped package checks, executable control skill, and feature map.
- S2: The frozen install, project hook, deterministic CI checks, and architectural enforcement checks pass without relaxed rules.
- S3: The direct control CLI reports the supported toolchain, launches an isolated runtime, creates through the actual web, and confirms a fresh authenticated Convex read.
- S4: The running MCP endpoint changes the persisted item, the reloaded web shows the change, and the local MCP App host renders and operates the shared UI.
- S5: Authentication and ownership denials are observed; redacted reports, logs, and screenshots survive successful cleanup.

## Proof choices

Use the generated [project profile](../project.md), [feature map](../feature-map/work-items/README.md), and [control skill](../../.codex/skills/astack-work-items/SKILL.md). Run the project scripts and the direct `doctor` and `verify` commands. The readiness journey is the retained exact regression for the mapped path. Additional exploratory or model-driven sessions are not selected for this scaffold trial; they would not establish the specified deterministic readiness contract.

Pencil is skipped because this task adopts the supported reference presentation without a new visual design decision. Existing Storybook stories remain part of the shared UI and its build checks; isolated Storybook browser proof is not selected because the actual web and MCP App browser journey covers the acceptance cases.

Live WorkOS sign-in, refresh, consent, organization lifecycle, installed ChatGPT OAuth/UI, and autonomous model tool selection require separate environments and are explicit gaps. Local signed disposable identities establish only the local authentication and authorization boundaries. No credentials belong in retained evidence.

## Trial boundaries

Use the existing repository and retain the project and evidence locally. Do not create a PR, push, merge, publish, contact anyone, or delegate recursively. The candidate scaffold is the authorized source; do not inspect the external trial harness or evaluator rubric.

Evidence is retained in `evidence/` beside this contract, with command outcomes, source identity, runtime observations, and cleanup results. Disposable credentials, deployment state, caches, and dependency directories remain ignored.
