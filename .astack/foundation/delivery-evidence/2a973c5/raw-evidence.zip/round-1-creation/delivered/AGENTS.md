# Foundation development

Run project commands from `app/`; use the enclosing workspace's existing Git repository.
Use Bun 1.4.0 and Node 24 (`.nvmrc` pins the version used for local proof).
Install with `bun install --frozen-lockfile` and preserve `bun.lock`.

Read `.astack/project.md` for check selection and runtime ownership. For running-product proof,
use `.codex/skills/astack-work-items/SKILL.md` and
`.astack/feature-map/work-items/README.md`. Run `doctor --json` before `verify --json`.
Preserve strict lint, type, architecture and authorization checks.

Portable UI receives data and callbacks through props; domain code stays deterministic and
browser safe. Convex owns persisted reactive state and checks identity and ownership at
each data operation. Web and MCP have distinct token audiences. Keep host and identity
adapters in their consuming apps.

Keep credentials, local database state, signing keys and authenticated browser state out
of Git and retained evidence. Preserve sanitized reports and screenshots under
`.astack/foundation-setup/evidence/`. Report live WorkOS and installed-host coverage
separately from disposable local proof.

This authorized trial stays local. Do not publish a PR, push, merge, contact anyone, or
launch recursive delivery trials.
