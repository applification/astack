# Foundation setup contract

Create a locally runnable work-item foundation in `app/` using the supplied candidate
scaffold, its frozen lockfile, and the existing workspace Git repository. Retain generated
source, project control instructions, feature map and sanitized evidence.

| Case | Observable acceptance                                                                                                                              | Proof route                                                                                 |
| ---- | -------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------- |
| S1   | Scaffold creates the supported web, MCP UI, Convex, portable UI, domain and config workspaces with provenance; the lock digest remains unchanged.  | `.astack/scaffold.json`, frozen install and provenance evidence.                            |
| S2   | Supported prerequisites and deterministic project checks succeed, with strict checks retained.                                                     | Node 24 doctor, quick/affected/CI checks, enforcement probes and installed pre-commit hook. |
| S3   | The local web creates persisted data; web and MCP read/change the same owned item. Wrong identities/audiences and malformed calls are rejected.    | Readiness R1–R6 and independent Convex reads.                                               |
| S4   | The local MCP App renders, follows host styling, survives remount, changes persisted status and acknowledges teardown; cleanup preserves evidence. | Readiness R7–R8, screenshots, host observations and `cleanup: complete`.                    |

Reuse the candidate's existing shared presentation and Storybook states. Pencil is skipped
because this task establishes the supplied foundation without selecting a new visual design.
Storybook's build is checked, and the actual web/MCP UI journey is observed in Chromium.
Keep the candidate's pinned Playwright control driver and isolated loopback Vite startup.
The exact readiness assertions and architecture probes provide the bounded discovery and
regression surface for this scaffold trial; model-driven exploration is skipped.

Local proof uses disposable signed identities. Live WorkOS sign-in/refresh, installed
ChatGPT OAuth/UI, production runtime behavior and autonomous model tool selection require
separate environments and remain explicit gaps. Local evidence supports only its named
cases. Read [the evidence index](evidence/README.md) for observed results and run lineage.
