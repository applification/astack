# Work items foundation

The React/Vite web app and authenticated Convex HTTP MCP endpoint share one owned work-item
domain. Its DTO is `id`, `title`, `status`; status is `open` or `done`. Production identity
is WorkOS. Local proof uses temporary signed JWTs with distinct web and MCP audiences.

Run commands from `app/` in the existing enclosing Git repository. Use Bun 1.4.0 and Node
24; `.nvmrc` pins the observed Node 24.21.0. Activate it with `nvm use` when available.
The initial shell resolved Node 22 and failed the doctor's prerequisite check; activate
Node 24 before running proof. Install with `bun install --frozen-lockfile` and prepare
Chromium with `bunx --no-install playwright install chromium`.

| Command                                        | Selection and claim                                                                                                                                                              |
| ---------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `bun run check:quick -- <files...>`            | Typed lint for named files; without arguments, Git edits/untracked files or all handwritten source. Gives fast feedback.                                                         |
| `bun run check:affected -- <base-ref>`         | Uses changes against the Git base (default `HEAD`); shared/config changes or uncertain scope broaden to the complete workspace. Runs lint, types and tests for broad selections. |
| `bun run check:ci`                             | Formatting, all handwritten lint/type checks, domain/proof tests, MCP/web bundles and Storybook build. Deterministic checks only.                                                |
| `bun run enforcement`                          | Deliberate invalid fixtures prove the adopted lint, portability and strict compiler checks reject their named violations. Restores probes/configuration on exit.                 |
| `bun run readiness --evidence <new-directory>` | Real disposable Convex + Vite + Chromium journey, independent persisted reads, MCP transport/auth boundaries and local AppBridge host.                                           |
| `bun run dev`                                  | Configured live WorkOS startup; follow the README environment/origin setup and use the actual printed URL.                                                                       |

The executable control route is
`./.codex/skills/astack-work-items/control.ts doctor --json`, then
`./.codex/skills/astack-work-items/control.ts verify --json --evidence <new-directory>`.
Read its [skill](../.codex/skills/astack-work-items/SKILL.md) and
[feature map](feature-map/work-items/README.md). Doctor reports checkout prerequisites;
verify creates and identifies its own live target. Backend/domain/shared UI changes
require both consuming surfaces because web and MCP share those boundaries.

Readiness owns its disposable Convex backend, Vite process, AppBridge host and browser.
It derives isolated free ports, verifies full Git revision plus source digest in web and
backend, creates through the web, reads independently, exercises web/MCP status changes,
checks denied identities/ownership, observes host styling/remount/teardown and cleans up.
Use a new evidence directory for each invocation. Credentials and local data stay in
private disposable state. Evidence survives cleanup. The default `.proof/` is ignored;
selected sanitized reports, logs and screenshots are retained in
[foundation setup evidence](foundation-setup/evidence/).

Frozen install configures `app/.husky/_` at the enclosing Git root. Its pre-commit hook
runs the pinned lint-staged formatter and typed ESLint checks from `app/`. Full deterministic
checks and readiness are local handoff gates; an enforced remote merge gate has not been
configured or verified in this disposable repository.

The [setup contract](foundation-setup/behavior-contract.md) records acceptance and design
choices. Read the [evidence index](foundation-setup/evidence/README.md) before making proof
claims. Readiness exercises the Vite development server; production bundles are built
by CI checks. Live WorkOS login/refresh/organization lifecycle, installed ChatGPT OAuth/UI,
production deployment and fresh-agent tool choice remain separate coverage gaps.

This trial retains the generated project and local evidence in the existing Git repository.
Publication, merges, messages and recursive delivery trials are outside its authorized scope.
