# Local foundation evidence

The candidate scaffold was invoked with the new `app/` destination from the existing
empty Git workspace. [Scaffold provenance](../../scaffold.json) identifies the source
revision and frozen lock digest. [Provenance inspection](provenance.json) confirms the
installed lock is unchanged and the project hook is at `app/.husky/_` in the enclosing
repository. All commands below run from `app/` with Bun 1.4.0.

| Observation                                                                             | Result and retained evidence                                                                                                                                                                                                                                                    |
| --------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `bun install --frozen-lockfile`                                                         | Passed; [frozen install log](frozen-install.log).                                                                                                                                                                                                                               |
| Direct control `--help` and `doctor --json`                                             | Executable CLI works. [Initial doctor](doctor.json) failed the Node prerequisite because the shell resolved Node 22. [Node 24 doctor](doctor-node24.json) passed all prerequisites after activating installed Node 24.21.0. Doctor identifies prerequisites, not a live target. |
| Chromium preparation                                                                    | `bunx --no-install playwright install chromium` passed; [log](chromium-install.log).                                                                                                                                                                                            |
| `bun run check:quick -- apps/web/src/main.tsx packages/backend/convex/workItems.ts`     | Passed typed lint for the named web/backend files; [log](check-quick.log).                                                                                                                                                                                                      |
| `bun run check:affected -- HEAD`                                                        | Selected the complete workspace against the original empty-workspace commit; lint, types and 32 tests passed; [log](check-affected.log).                                                                                                                                        |
| `bun run check:ci` under Node 24.21.0                                                   | Passed formatting, typed lint, workspace/root types, 32 tests, MCP/web production bundles and Storybook build; [log](check-ci-node24.log).                                                                                                                                      |
| `bun run enforcement`                                                                   | All 15 cases passed; [log](enforcement.log), [formatted report](enforcement-report.json), [original report bytes](enforcement-report.json.raw). Invalid fixtures and modified compiler configuration were cleaned up.                                                           |
| Direct control `verify --json --evidence .astack/foundation-setup/evidence/readiness-1` | Eight checks passed with two explicitly skipped external layers; [report](readiness-1/report.json). Runtime cleanup completed.                                                                                                                                                  |

The first readiness run verified the generated source at full Git revision plus source
digest recorded in its report. It identified its isolated loopback web/Convex/MCP targets,
created through the actual browser, confirmed fresh persisted reads, exercised status
changes across web and MCP, rejected ownership/authentication violations, validated MCP
contracts and exercised local AppBridge styles, remount and teardown.

The [web screenshot](readiness-1/web-persisted.png) and
[MCP App screenshot](readiness-1/mcp-app-host.png) were visually inspected. They show the
same completed disposable item. [Host observations](readiness-1/mcp-host-observations.json)
record theme changes, two mounts, two teardown acknowledgements, four closed owned
connections and no uncaught App errors. Screenshots and redacted logs survived cleanup.

First observations are preserved: [initial Node 22 CI run](check-ci.log) passed its
deterministic checks, and [first Node 24 CI attempt](check-ci-node24-format-failure.log)
stopped because the retained enforcement JSON needed formatting. Its raw bytes were
preserved separately, the JSON copy was formatted, and the full Node 24 CI rerun passed.
No check configuration or assertion was weakened. Vite reports advisory large-chunk
warnings for the web and Storybook builds.

Live WorkOS sign-in/refresh/organization lifecycle and installed ChatGPT OAuth/UI/tool
selection are skipped (G1/G2). Local signed identities and the AppBridge fixture establish
the named local boundaries. The running web proof uses Vite development mode; production
bundles were built but production runtime behavior was not exercised. No remote merge
gate, production deployment or model-driven exploration was verified. This local trial
does not run recursive delivery agents or publish repository changes.

Retained text is scanned for JWTs, private keys, token-shaped Bearer [REDACTED] and named
deployment-secret assignments. Ephemeral tokens, signing keys and database state stay
outside evidence and are deleted by runtime cleanup. This inspection is scoped to those
patterns plus visual inspection of the selected screenshots.

The final `bun run readiness --evidence .astack/foundation-setup/evidence/readiness-2`
also passed R1–R8 and completed cleanup, with G1/G2 explicitly skipped. Its
[report](readiness-2/report.json) identifies source commit
`70421c236bbd347b85e3d5ed760e78679637a1b9` and source SHA-256
`65e839673ed15771250a3ffddaf5da0ee7940547ce9f84ce7180a60fcc819b1c`.
The current source identity was independently compared with that report and matched.
The [final web screenshot](readiness-2/web-persisted.png) and
[final MCP App screenshot](readiness-2/mcp-app-host.png) were visually inspected.

The [foundation commit log](git-foundation-commit.log) records successful project
pre-commit preparation, formatting and typed ESLint in the existing repository.
The following evidence-only commit retains this final run without changing the proved
source. [Retention inspection](retention.json) records artifact hashes, credential-pattern
inspection, and independent checks that the run's three listening ports are closed.

Raw tool logs contained trailing spaces which Git's whitespace check reported.
For each affected log, original bytes are retained in a neighboring `.log.gz` file;
the readable `.log` removes line-ending horizontal whitespace only. Retention metadata
records original, archive and readable SHA-256 values. The original enforcement JSON
also remains in `.json.raw`. These evidence transformations preserve observations and
leave every project check unchanged.
