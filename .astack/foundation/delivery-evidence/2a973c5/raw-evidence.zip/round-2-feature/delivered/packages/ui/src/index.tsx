import type { ComponentProps, ReactNode } from 'react';
import { useEffect, useId, useRef } from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva } from 'class-variance-authority';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { WorkItem } from '@foundation/domain';

// shadcn's button/input pattern, with styling kept in the portable package.
const buttonVariants = cva('button', {
  variants: {
    variant: { primary: 'button-primary', secondary: 'button-secondary' },
  },
  defaultVariants: { variant: 'primary' },
});
export function Button({
  className,
  variant = 'primary',
  asChild = false,
  ...props
}: ComponentProps<'button'> & {
  variant?: 'primary' | 'secondary';
  asChild?: boolean;
}) {
  const Component = asChild ? Slot : 'button';
  return (
    <Component
      className={twMerge(clsx(buttonVariants({ variant }), className))}
      {...props}
    />
  );
}
export function Input({ className, ...props }: ComponentProps<'input'>) {
  return <input className={twMerge(clsx('input', className))} {...props} />;
}
export function Workspace({
  actions,
  children,
}: {
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <main className="workspace">
      <header className="page-header">
        <div>
          <p className="eyebrow">ASTACK REFERENCE</p>
          <h1>Work items</h1>
          <p className="subtitle">Keep a clear record of what needs doing.</p>
        </div>
        {actions}
      </header>
      {children}
    </main>
  );
}
export function Notice({ children }: { children: ReactNode }) {
  return (
    <p className="notice" role="status">
      {children}
    </p>
  );
}
export function Dialog({
  title,
  children,
  onClose,
  pending = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  pending?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  useEffect(() => {
    const dialog = ref.current;
    const previousFocus = document.activeElement;
    dialog?.showModal();
    return () => {
      dialog?.close();
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected)
        previousFocus.focus();
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className="edit-dialog"
      aria-labelledby={titleId}
      onCancel={(event) => {
        event.preventDefault();
        if (!pending) onClose();
      }}
    >
      <h2 id={titleId}>{title}</h2>
      {children}
    </dialog>
  );
}
export function WorkItemList({
  items,
  pendingId,
  onStatusChange,
  onEdit,
}: {
  items: WorkItem[];
  pendingId?: string;
  onStatusChange: (item: WorkItem) => void;
  onEdit?: (item: WorkItem) => void;
}) {
  if (items.length === 0)
    return (
      <div className="empty">
        <h2>Nothing here yet</h2>
        <p>Add a work item to get started.</p>
      </div>
    );
  return (
    <ul className="work-list">
      {items.map((item) => (
        <li className="work-item" key={item.id}>
          <span className={`status-dot ${item.status}`} aria-hidden="true" />
          <div className="item-copy">
            <h2>{item.title}</h2>
            <span className="item-state">
              {item.status === 'done' ? 'Completed' : 'Ready to work on'}
            </span>
          </div>
          {onEdit && (
            <Button
              type="button"
              variant="secondary"
              disabled={pendingId !== undefined}
              aria-label={`Edit ${item.title}`}
              onClick={() => {
                onEdit(item);
              }}
            >
              Edit
            </Button>
          )}
          <Button
            type="button"
            variant="secondary"
            disabled={pendingId !== undefined}
            onClick={() => {
              onStatusChange(item);
            }}
          >
            {pendingId === item.id
              ? 'Saving…'
              : item.status === 'open'
                ? 'Mark done'
                : 'Reopen'}
          </Button>
        </li>
      ))}
    </ul>
  );
}
