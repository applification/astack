import { describe, expect, test } from 'bun:test';
import assert from 'node:assert/strict';
import type { UserIdentity } from 'convex/server';
import { ConvexError } from 'convex/values';
import type { WorkItem, WorkStatus } from '@foundation/domain';
import type { Doc, Id } from '../packages/backend/convex/_generated/dataModel';
import type { MutationCtx } from '../packages/backend/convex/_generated/server';
import { setStatus } from '../packages/backend/convex/workItems';

// Convex exposes this hook at runtime but omits internal hooks from its public
// declarations. Keep the test adapter typed to this mutation's actual contract.
const statusHandler = (
  setStatus as typeof setStatus & {
    _handler: (
      ctx: MutationCtx,
      args: { id: Id<'workItems'>; status: WorkStatus },
    ) => Promise<WorkItem>;
  }
)._handler;

const id = 'status-regression-item' as Id<'workItems'>;
const owner: UserIdentity = {
  subject: 'user_status_owner',
  issuer: 'https://identity.example',
  tokenIdentifier: 'https://identity.example|user_status_owner',
};

function denialCode(code: 'FORBIDDEN' | 'UNAUTHENTICATED') {
  return (error: unknown) => {
    if (!(error instanceof ConvexError)) return false;
    const data: unknown = error.data;
    return (
      data !== null &&
      typeof data === 'object' &&
      'code' in data &&
      data.code === code
    );
  };
}

function fixture(
  identity: UserIdentity | null = owner,
  exists = true,
  initialStatus: 'open' | 'done' = 'open',
) {
  let stored: Doc<'workItems'> | null = exists
    ? {
        _id: id,
        _creationTime: 1,
        owner: owner.subject,
        title: 'Persist the requested status',
        status: initialStatus,
      }
    : null;
  let writes = 0;
  const read = () => (stored === null ? null : { ...stored });
  // This handler fixture exercises persistence and ownership logic. Convex's
  // argument validators are exercised separately against the live backend.
  const ctx = {
    auth: { getUserIdentity: () => Promise.resolve(identity) },
    db: {
      get: (requestedId: Id<'workItems'>) => {
        expect(requestedId).toBe(id);
        return Promise.resolve(read());
      },
      patch: (
        requestedId: Id<'workItems'>,
        patch: Partial<Doc<'workItems'>>,
      ) => {
        expect(requestedId).toBe(id);
        if (stored === null) throw new Error('Cannot patch a missing item');
        stored = { ...stored, ...patch };
        writes += 1;
        return Promise.resolve();
      },
    },
  } as unknown as MutationCtx;
  return { ctx, read, writes: () => writes };
}

describe('persisted work-item status', () => {
  test('reopening a done item persists open and preserves its other fields', async () => {
    const db = fixture(owner, true, 'done');
    const original = db.read();
    assert.ok(original);
    const result = await statusHandler(db.ctx, { id, status: 'open' });
    expect(db.read()).toEqual({ ...original, status: 'open' });
    expect(result).toEqual({ id, title: original.title, status: 'open' });
  });

  test('done, repeated done, reopen and repeated reopen agree with stored state', async () => {
    const db = fixture();
    const original = db.read();
    assert.ok(original);
    for (const status of ['done', 'done', 'open', 'open'] as const) {
      const result = await statusHandler(db.ctx, { id, status });
      const persisted = db.read();
      assert.ok(persisted);
      expect(persisted).toEqual({ ...original, status });
      expect(result).toEqual({ id, title: original.title, status });
      expect(result.status).toBe(persisted.status);
    }
  });

  for (const status of ['done', 'open'] as const) {
    test(`another owner cannot set ${status} or write any state`, async () => {
      const db = fixture({
        ...owner,
        subject: 'user_status_other',
        tokenIdentifier: 'https://identity.example|user_status_other',
      });
      const original = db.read();
      await assert.rejects(
        () => statusHandler(db.ctx, { id, status }),
        denialCode('FORBIDDEN'),
      );
      expect(db.writes()).toBe(0);
      expect(db.read()).toEqual(original);
    });

    test(`anonymous callers cannot set ${status} or write any state`, async () => {
      const db = fixture(null);
      const original = db.read();
      await assert.rejects(
        () => statusHandler(db.ctx, { id, status }),
        denialCode('UNAUTHENTICATED'),
      );
      expect(db.writes()).toBe(0);
      expect(db.read()).toEqual(original);
    });

    test(`a missing item cannot be set ${status}`, async () => {
      const db = fixture(owner, false);
      await assert.rejects(
        () => statusHandler(db.ctx, { id, status }),
        denialCode('FORBIDDEN'),
      );
      expect(db.writes()).toBe(0);
      expect(db.read()).toBeNull();
    });
  }
});
