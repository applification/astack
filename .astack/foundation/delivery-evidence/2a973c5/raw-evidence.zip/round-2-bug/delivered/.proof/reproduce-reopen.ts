import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { chromium } from 'playwright';
import { ConvexHttpClient } from 'convex/browser';
import { makeFunctionReference } from 'convex/server';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { WorkItemsResultSchema, WorkItemSchema } from '@foundation/domain';
import { startRuntime, redact, waitFor } from '../scripts/runtime';
import { HttpTransport } from '../scripts/http-transport';
import { expectPersistedStatus, items } from '../scripts/readiness';

const evidence = '.proof/reopen-before';
await mkdir(evidence, { recursive: true });
const runtime = await startRuntime({ projectRoot: process.cwd() });
const browser = await chromium.launch();
const mcp = new Client({ name: 'status-reproduction', version: '1' });
const observations: unknown[] = [];
try {
  const owner = new ConvexHttpClient(runtime.convexUrl);
  owner.setAuth(runtime.tokens.web);
  const list = makeFunctionReference<'query'>('workItems:list');
  const page = await browser.newPage();
  await page.goto(runtime.webUrl);
  const title = 'Reproduce persisted reopen';
  await page.getByLabel('Title', { exact: true }).fill(title);
  await page.getByRole('button', { name: 'Add work item', exact: true }).click();
  await page.getByText(title, { exact: true }).waitFor();
  const item = await waitFor(async () => items(await owner.query(list, {})).find(value => value.title === title) ?? false, 'created item');
  await mcp.connect(new HttpTransport(new URL(runtime.mcpUrl), {
    requestInit: { headers: { authorization: `Bearer ${runtime.tokens.mcp}` } },
  }));
  const response = await mcp.callTool({ name: 'work_items_set_status', arguments: { id: item.id, status: 'open' } });
  assert.notEqual(response.isError, true);
  const returned = WorkItemSchema.parse((response.structuredContent as { item: unknown }).item);
  const backend = items(await owner.query(list, {})).find(value => value.id === item.id);
  const listed = await mcp.callTool({ name: 'work_items_list', arguments: {} });
  assert.notEqual(listed.isError, true);
  const mcpStatus = WorkItemsResultSchema.parse(listed.structuredContent).items.find(value => value.id === item.id)?.status;
  observations.push({ action: 'MCP set open', expected: 'open', returned: returned.status, backend: backend?.status, mcp: mcpStatus });
  assert.equal(backend?.status, 'done', 'The unchanged backend must exhibit the reported inversion');
  await page.reload();
  await page.getByRole('button', { name: 'Reopen', exact: true }).click();
  const control = page.getByRole('button', { name: /^(Mark done|Reopen)$/ });
  await waitFor(async () => (await control.count()) === 1 && (await control.isEnabled()), 'reopen settled');
  try {
    await expectPersistedStatus(() => owner.query(list, {}), item.id, 'open');
    assert.fail('Expected unchanged product to reproduce the reopen mismatch');
  } catch (error) {
    if (!(error instanceof assert.AssertionError)) throw error;
    const fresh = items(await owner.query(list, {})).find(value => value.id === item.id);
    const mcpRead = await mcp.callTool({ name: 'work_items_list', arguments: {} });
    assert.notEqual(mcpRead.isError, true);
    const mcpItem = WorkItemsResultSchema.parse(mcpRead.structuredContent).items.find(value => value.id === item.id);
    observations.push({ action: 'Web Reopen', expected: 'open', webControl: await control.innerText(), backend: fresh?.status, mcp: mcpItem?.status, observation: redact(String(error)) });
  }
  await page.screenshot({ path: `${evidence}/web-reopen.png`, fullPage: true });
} finally {
  await mcp.close();
  await browser.close();
  await runtime.stop();
  const report = { revision: runtime.buildId, observations, cleanup: 'complete' };
  await writeFile(`${evidence}/report.json`, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
}
