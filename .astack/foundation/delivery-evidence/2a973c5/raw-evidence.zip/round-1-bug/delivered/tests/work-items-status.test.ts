import { expect, test } from 'bun:test';
import { ConvexHttpClient } from 'convex/browser';
import { makeFunctionReference } from 'convex/server';
import { WorkItemSchema, WorkItemsResultSchema } from '@foundation/domain';
import { startRuntime } from '../scripts/runtime';

const create = makeFunctionReference<'mutation'>('workItems:create');
const setStatus = makeFunctionReference<'mutation'>('workItems:setStatus');
const list = makeFunctionReference<'query'>('workItems:list');

test('status mutation responses agree with fresh persisted reads, including repeated done and reopen requests', async () => {
  const runtime = await startRuntime();
  try {
    const writer = new ConvexHttpClient(runtime.convexUrl);
    writer.setAuth(runtime.tokens.web);
    const item = WorkItemSchema.parse(
      await writer.mutation(create, { title: 'Persist requested status' }),
    );
    expect(item.status).toBe('open');

    for (const status of ['done', 'done', 'open', 'open', 'done'] as const) {
      const returned = WorkItemSchema.parse(
        await writer.mutation(setStatus, { id: item.id, status }),
      );
      // A separate HTTP client reads the database, not a mutation response or
      // a browser subscription that could conceal a persisted mismatch.
      const reader = new ConvexHttpClient(runtime.convexUrl);
      reader.setAuth(runtime.tokens.web);
      const rawItems: unknown = await reader.query(list, {});
      const persisted = WorkItemsResultSchema.parse({
        items: rawItems,
      }).items.find((value) => value.id === item.id);
      expect(returned).toEqual({ ...item, status });
      expect(persisted).toEqual(returned);
    }
  } finally {
    await runtime.stop();
  }
}, 120_000);
