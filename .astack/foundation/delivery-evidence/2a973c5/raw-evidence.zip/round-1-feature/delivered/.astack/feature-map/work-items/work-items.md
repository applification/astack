# Create and change work items

In the web app, open **Work items**, fill **Title**, and select **Add work item**. The new item appears in the authenticated list. **Mark done** and **Reopen** change its status. URL status filtering limits the list to the chosen state. The row action **Edit** (accessible as `Edit <current title>`) opens the **Edit work item** dialog. Edit **Title** and select **Save changes**, or select **Cancel** / press Escape to discard the draft. Invalid or blank titles stay in the dialog with validation feedback.

The MCP tools `work_items_list`, `work_items_create`, `work_items_set_status`, `work_items_update_title`, and `work_items_delete` reach the same domain. `work_items_update_title({id,title})` calls Convex `workItems:updateTitle({id,title})`, preserving the item's owner and status. Titles use the same trimming and 1–160 character validation as creation. Both mutations require authentication and ownership. The MCP App opens the `ui://foundation/work-items.html` resource in a compatible host.

Run `./.codex/skills/astack-work-items/control.ts verify --json`. It creates through the actual web, checks a fresh Convex read, changes status through the running MCP endpoint, reloads the web and renders the resource through AppBridge. A visible row supports presentation; the independent authenticated query supports persistence. It also checks anonymous, expired, wrong-audience and other-user denials.

Run `bun scripts/readiness.ts --task-profile title-edit --evidence .proof/title-edit` for the baseline checks plus web title edits read freshly through Convex/MCP, MCP title edits read freshly through Convex/reloaded web, blank-title rejection on all three surfaces, and another user's denied title edits through Convex and MCP. Read every outcome in the retained `report.json` before claiming proof.

Prerequisites are installed frozen dependencies and Chromium (`bunx playwright install chromium` if unavailable). The local proof issuer is allowed only in the disposable loopback environment. It verifies ownership and authentication boundaries; it does not verify live WorkOS login or the installed ChatGPT host.
