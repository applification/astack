# Observed foundation proof

Overall outcome: **partial**. The candidate scaffold created `app/`, frozen installation succeeded with the original lock, the direct local MCP proof passed, and the project and sanitized evidence remain in the enclosing Git workspace. Full deterministic CI and rendered browser readiness remain blocked by this sandbox.

| Check | Observation | Evidence |
| --- | --- | --- |
| Candidate scaffold and frozen install | Passed; lock SHA-256 still matches `.astack/scaffold.json`. Initial home-cache permission failures are retained. | [Setup](setup.json), [project-cache install](install-project-cache.log). |
| Direct control CLI | Executable help worked. Final doctor passes Bun 1.4.0, Node 24.21.0, dependencies and lock prerequisites. | [Initial doctor](doctor-initial.json), [final doctor](doctor-final.json). |
| Quick typed lint | Passed for the added supplemental proof script. | [Quick check](check-quick.log). |
| Deterministic CI | Formatting, MCP bundle, lint and all type checks passed. Tests: 17 pass, 1 fail because `/bin/ps` is prohibited. CI stopped at that failure. | [First failure](check-ci-initial.log), [final rerun](check-ci-final.log). |
| Affected checks | Correctly selected the complete workspace, then reached the same sandbox-related test failure. | [Affected check](check-affected.log). |
| Enforcement | All 15 cases passed, including rejection of unsafe types/promises, inaccessible UI, invalid hooks, boundary violations and an invalid compiler assignment. Probe files were removed and configuration restored. | [Report](enforcement-report.json), [command](enforcement-command.log). |
| Production bundles | Web, MCP UI and Storybook builds passed; Vite emitted size warnings. These are build observations. | [Build](build.log). |
| Full browser readiness | Disposable Convex and Vite started with identified builds. Chromium Mach service registration was denied, so no browser acceptance case ran. Both runs are inconclusive with cleanup complete. | [Initial report](readiness-initial/report.json), [final report](readiness-final/report.json). |
| Direct live MCP readiness | All M1–M9 passed: identified backend and served web entry, discovery, SDK initialization/tools, create/list/status/delete with independent Convex reads, credential denials, ownership denials and self-contained UI packaging. Cleanup verified process closure and private runtime removal. | [First report](mcp-readiness/report.json), [final report](mcp-final/report.json). |

Final doctor and both final readiness reports identify the same dirty source: Git revision `b2a5a493543ea0134d348a51eddf8b2a314587cb` with SHA-256 `900c0930043b62c3ea064139f77d8e743002bd93169efecfe4e3a5fbfb098e99`. No nested Git repository was initialized. The generated project remains as working-tree files; trial Git metadata is read-only.

The first/final report pairs retain rerun history rather than overwriting initial failures. The supplemental MCP pass does not change the full readiness outcome. [The manifest](manifest.json) records evidence hashes, lock integrity, identity, removed fixtures and credential inspection; [the summary](summary.json) records final results and cleanup observations.

Material gaps: `/bin/ps` prevents green CI/affected checks; Chromium permissions prevent web interaction and AppBridge rendering. Live WorkOS sign-in/refresh/consent, installed ChatGPT and model tool selection were not exercised. Vite readiness uses the development server, so production browser behavior is unverified. Husky reports that `.git` cannot be found from nested `app/`; hook activation was not performed. No credentials, keys, database state or private runtime directories were retained.

To repeat in a compatible local environment, use Node 24 in subprocess `PATH`, then run the documented commands from `app/`, choosing fresh evidence directories. Keep the required checks and original readiness route intact.
