# Foundation project

Run commands from `app/` in the enclosing workspace's existing Git repository.
Use Node 24 and Bun 1.4.x, the committed frozen `bun.lock`, and the package scripts.
`bunfig.toml` keeps installation cache writes within ignored `node_modules/`.

Read `.astack/project.md`, `.codex/skills/astack-work-items/SKILL.md` and
`.astack/feature-map/work-items/README.md` before driving the product.
Portable UI/domain boundaries are enforced by `packages/config/eslint.mjs`.
Keep WorkOS secrets server-side and authorization at the Convex operations.

Use `check:quick` for named edited files, `check:affected -- HEAD` for dependency
impact, and `check:ci` for all retained deterministic checks. `readiness` and the
control skill's `verify` command are the separate browser/web/MCP integration
gate. `readiness:mcp` supplies direct live MCP and Convex observations when a
browser cannot start; it cannot establish browser or AppBridge behavior.

Keep the first failure and fresh rerun reports. Retain sanitized trial evidence
in the enclosing workspace's `evidence/` directory. Never store tokens, private
keys, environment files or disposable database state there.

<!-- BEGIN:turborepo-agent-rules -->

# This is NOT the Turborepo you know

Turborepo configuration, task behavior, and CLI commands can vary between installed versions and may differ from your training data. Resolve the `turbo` package from this file's directory or relevant workspace; in monorepos, it may not be visible from the repository root. For example, run `node -p "require.resolve('turbo/package.json')"` from a workspace that depends on `turbo`.

Read `docs/README.md` inside that installed package first, then read the relevant pages from its `docs/` directory before changing Turborepo configuration or commands. Heed deprecation notices. These bundled docs match the installed package version and are available without network access.

This block is written and re-added by `turbo` before repository-scoped commands when an AI agent is detected. In the Turborepo source repository, its template is defined in `crates/turborepo-cli/src/cli/agent_guidance.rs`. Removing the managed block while updates are enabled means a later qualifying invocation will add it again. Set `"agentGuidance": false` in the root `turbo.json` or `turbo.jsonc` to opt out; this does not remove an existing block. Keep the block committed with your work to avoid an uncommitted change on the next agent invocation.
<!-- END:turborepo-agent-rules -->
