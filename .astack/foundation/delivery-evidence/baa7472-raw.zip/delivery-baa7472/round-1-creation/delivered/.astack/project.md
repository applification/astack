# Work items reference

This disposable reference shares one Convex domain across a React/Vite web app and authenticated MCP Apps endpoint. Its canonical DTO is `id`, `title`, `status`; status is `open` or `done`. Production identity is WorkOS. Local proof uses temporary signed JWTs with distinct web and MCP audiences and no external account.

From this directory run `bun install --frozen-lockfile`, `bun run typecheck`, `bun run test`, `bun run build` and `bun run verify`. The direct product control route is `./.codex/skills/astack-work-items/control.ts doctor --json` then `./.codex/skills/astack-work-items/control.ts verify --json`. Its tracked feature map is `.astack/feature-map/work-items/README.md`.

`verify` owns its disposable Convex backend, Vite process and browser. It derives separate free ports, confirms backend and web build identity, drives the user path, independently reads persisted effects, and cleans up. `.proof/<run>/report.json` and screenshots remain; tokens, private signing keys, database state and environment files are excluded from retained evidence and Git. Never point this route at production or a shared local deployment.

The local MCP App host is a real SDK bridge to the running endpoint. Live WorkOS identity and installed ChatGPT OAuth/UI are separate, explicit proof gaps until exercised with authorized test accounts. Do not relabel local results as those host results.

## Local foundation trial

The supported scaffold was invoked with the new `app/` destination inside the existing enclosing Git repository. Do not initialize another repository. `.astack/scaffold.json` records the candidate revision and the unchanged frozen lock hash.

Use Node 24 in the subprocess `PATH`, not merely a shell alias. This host's default subprocess path initially selected Node 22. `bunfig.toml` places Bun's cache in ignored `node_modules/.cache/bun`, allowing installs in both this checkout and disposable runtime copies without writes to a home-directory cache. `TMPDIR=/private/tmp` was used for the observed trial commands.

| Command from `app/`                                           | Scope                                                                                                        |
| ------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| `bun install --frozen-lockfile`                               | Locked dependency installation.                                                                              |
| `bun run check:quick -- scripts/readiness-mcp.ts`             | Typed lint for named files; not integration proof.                                                           |
| `bun run check:affected -- HEAD`                              | Git changes plus untracked inputs; shared or uncertain changes select all consumer checks.                   |
| `bun run check:ci`                                            | Formatting, every workspace lint/typecheck, retained tests and browser bundle builds.                        |
| `bun run enforcement`                                         | Deliberately invalid fixtures demonstrate adopted lint/compiler rejection, with fixtures restored afterward. |
| `bun run build`                                               | Production web/MCP UI and component-story bundles; not rendered browser proof.                               |
| `bun run readiness -- --evidence ../evidence/readiness-final` | Disposable Convex + Vite + Chromium, web persistence, MCP and AppBridge.                                     |
| `bun run readiness:mcp -- --evidence ../evidence/mcp-final`   | Separate direct MCP/Convex observations and HTTP web startup; no browser or AppBridge interaction.           |

The primary control skill and feature map remain the routes linked above. `doctor` reports checkout prerequisites; `verify` owns its isolated processes and state. Evidence is retained in the enclosing workspace's `evidence/` directory, including the first failures. Both readiness routes delete their private runtime copies; supplemental cleanup also checks removal and process closure.

The trial sandbox forbids `/bin/ps`, causing one retained process-accounting test to fail, and denies Chromium's Mach service registration, making full browser readiness inconclusive. Keep both required checks intact. The nested install reports that Husky cannot find `.git`; hook activation was not performed because this trial's Git metadata is read-only. Actual WorkOS, installed ChatGPT and fresh model-driven tool selection remain separate unverified layers. See [the setup contract](foundation-setup/behavior-contract.md) and [retained evidence](../../evidence/).
