# Local foundation setup

Create the candidate's supported Convex + WorkOS + MCP foundation in `app/`, use the enclosing Git repository, install the frozen lock, exercise retained checks and demonstrate disposable local readiness. No publication, external messages or recursive delegation are part of this trial.

| Case | Expected observation                                                                                                               | Check and retained evidence                                                                                                 |
| ---- | ---------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| S1   | The requested scaffold produces a separate app with source provenance.                                                             | `.astack/scaffold.json`; `../../../evidence/setup.json`.                                                                    |
| S2   | Frozen installation succeeds without changing the lock.                                                                            | `install-project-cache.log` and the independent SHA-256 comparison in setup evidence.                                       |
| S3   | All deterministic checks pass, and invalid boundary fixtures are rejected.                                                         | `check:ci`, `check:affected`, `enforcement`; the process-accounting test is blocked by the sandbox's `/bin/ps` prohibition. |
| S4   | The control CLI drives rendered web persistence, MCP and the local AppBridge host.                                                 | `doctor`, direct `verify`, `readiness`; browser launch is inconclusive because Mach service registration is denied.         |
| S5   | A live MCP client can create/list/change/delete owned data, with fresh Convex reads and specific authentication/ownership denials. | Separate `readiness:mcp`, checks M1–M9. This supports protocol and HTTP startup claims only.                                |
| S6   | Temporary credentials, database state and owned processes are removed; sanitized evidence survives.                                | Readiness cleanup and the evidence inspection manifest.                                                                     |

The scaffold's established UI, stories and Playwright driver are preserved. Pencil is skipped because this is foundation setup with no visual redesign; existing Storybook states are built as component evidence. No testing-tool migration or model exploration is selected for this fixed baseline trial. Exact live MCP operations provide the additional bounded observations available in this sandbox.

Live WorkOS sign-in/refresh/consent, installed ChatGPT, autonomous model tool selection and production browser interactions require separate environments. A successful build or supplemental protocol run cannot make S3 or S4 pass. The enclosing `evidence/README.md` records final observations and rerun lineage.
