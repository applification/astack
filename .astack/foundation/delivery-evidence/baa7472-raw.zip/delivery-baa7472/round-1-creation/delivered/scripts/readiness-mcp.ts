import assert from 'node:assert/strict';
import { access, mkdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { ConvexHttpClient } from 'convex/browser';
import { makeFunctionReference } from 'convex/server';
import { z } from 'zod';
import { WorkItemSchema } from '@foundation/domain';
import { HttpTransport } from './http-transport';
import { denied, items, selfContainedResource } from './readiness';
import { redact, revisionIdentity, startRuntime } from './runtime';
import type { Runtime } from './runtime';

// Separate protocol observations: this never replaces the browser readiness gate.
const { values } = parseArgs({
  options: { evidence: { type: 'string' } },
});
const evidence = resolve(
  values.evidence ?? join('.proof', `mcp-${Date.now()}`),
);
await mkdir(evidence, { recursive: true });
const checks: {
  id: string;
  outcome: 'pass' | 'fail' | 'inconclusive';
  observation: string;
}[] = [];
const report = {
  format: 'astack-foundation-mcp-readiness/v1',
  startedAt: new Date().toISOString(),
  finishedAt: '',
  revision: await revisionIdentity(process.cwd()),
  outcome: 'inconclusive' as 'pass' | 'fail' | 'inconclusive',
  scope: 'Live local MCP and independent Convex reads; web HTTP startup only.',
  environment: {} as Record<string, string>,
  checks,
  gaps: [
    'Rendered browser interaction and local AppBridge host behavior are not exercised.',
    'Live WorkOS login, refresh and consent are not exercised.',
    'Installed ChatGPT and autonomous model tool selection are not exercised.',
    'Vite development runtime; production browser behavior is not exercised.',
  ],
  cleanup: 'complete' as 'complete' | 'failed',
  error: '',
  artifacts: ['report.json', 'runtime.log'],
};
let runtime: Runtime | undefined;
const clients: Client[] = [];
async function check<T>(
  id: string,
  observation: string,
  action: () => Promise<T>,
): Promise<T> {
  try {
    const result = await action();
    checks.push({ id, outcome: 'pass', observation });
    return result;
  } catch (error) {
    checks.push({
      id,
      outcome: error instanceof assert.AssertionError ? 'fail' : 'inconclusive',
      observation: redact(String(error)),
    });
    throw error;
  }
}
async function connect(active: Runtime, token: string): Promise<Client> {
  const client = new Client({
    name: 'foundation-local-mcp-proof',
    version: '1',
  });
  clients.push(client);
  await client.connect(
    new HttpTransport(new URL(active.mcpUrl), {
      requestInit: { headers: { authorization: `Bearer [REDACTED] } },
    }),
  );
  return client;
}
try {
  runtime = await startRuntime();
  const active = runtime;
  report.revision = active.buildId;
  report.environment = {
    buildId: active.buildId,
    web: active.webUrl,
    convex: active.convexUrl,
    mcp: active.mcpUrl,
    actors: 'proof-owner-a, proof-owner-b',
    credentialPolicy:
      'Ephemeral signed identities; no retained tokens or keys.',
  };
  await check(
    'M1',
    'Backend health matches this build; the Vite entry is served.',
    async () => {
      const health = z
        .object({
          buildId: z.string(),
          resource: z.string(),
          authMode: z.string(),
        })
        .parse(await (await fetch(`${active.siteUrl}/health`)).json());
      assert.equal(health.buildId, active.buildId);
      assert.equal(health.resource, active.mcpUrl);
      assert.equal(health.authMode, 'local-proof');
      const web = await fetch(active.webUrl);
      assert.equal(web.status, 200);
      assert.ok((await web.text()).includes('/src/main.tsx'));
    },
  );
  await check(
    'M2',
    'Protected-resource discovery advertises the exact MCP resource and local issuer.',
    async () => {
      const metadata = z
        .object({
          resource: z.string(),
          authorization_servers: z.array(z.string()),
        })
        .parse(
          await (
            await fetch(
              `${active.siteUrl}/.well-known/oauth-protected-resource/mcp`,
            )
          ).json(),
        );
      assert.equal(metadata.resource, active.mcpUrl);
      assert.deepEqual(metadata.authorization_servers, [active.issuer]);
    },
  );
  const mcp = await check(
    'M3',
    'A real SDK client initializes and lists all four work-item tools.',
    async () => {
      const client = await connect(active, active.tokens.mcp);
      const tools = await client.listTools();
      assert.deepEqual(tools.tools.map((tool) => tool.name).sort(), [
        'work_items_create',
        'work_items_delete',
        'work_items_list',
        'work_items_set_status',
      ]);
      return client;
    },
  );
  const list = makeFunctionReference<'query'>('workItems:list');
  const owner = new ConvexHttpClient(active.convexUrl);
  owner.setAuth(active.tokens.web);
  const item = await check(
    'M4',
    'MCP creation persists in a fresh authenticated Convex read.',
    async () => {
      const result = await mcp.callTool({
        name: 'work_items_create',
        arguments: { title: 'Disposable MCP readiness item' },
      });
      assert.notEqual(result.isError, true);
      const created = z
        .object({ item: WorkItemSchema })
        .parse(result.structuredContent).item;
      assert.equal(created.status, 'open');
      assert.deepEqual(items(await owner.query(list, {})), [created]);
      return created;
    },
  );
  await check(
    'M5',
    'MCP done and reopen mutations survive independent Convex reads and MCP listing.',
    async () => {
      for (const status of ['done', 'open']) {
        const result = await mcp.callTool({
          name: 'work_items_set_status',
          arguments: { id: item.id, status },
        });
        assert.notEqual(result.isError, true);
        assert.equal(
          items(await owner.query(list, {})).find(
            (value) => value.id === item.id,
          )?.status,
          status,
        );
        const listed = await mcp.callTool({
          name: 'work_items_list',
          arguments: {},
        });
        assert.notEqual(listed.isError, true);
        const content = z
          .object({ items: z.array(WorkItemSchema) })
          .parse(listed.structuredContent);
        assert.equal(
          content.items.find((value) => value.id === item.id)?.status,
          status,
        );
      }
    },
  );
  await check(
    'M6',
    'Anonymous, web-audience, wrong-resource and expired identities receive HTTP 401; anonymous Convex reads are denied.',
    async () => {
      for (const token of [
        undefined,
        active.tokens.web,
        active.tokens.wrongAudience,
        active.tokens.expired,
      ]) {
        const response = await fetch(active.mcpUrl, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            accept: 'application/json, text/event-stream',
            ...(token ? { authorization: `Bearer [REDACTED] } : {}),
          },
          body: JSON.stringify({
            jsonrpc: '2.0',
            id: 1,
            method: 'initialize',
            params: {
              protocolVersion: '2025-03-26',
              capabilities: {},
              clientInfo: { name: 'negative-proof', version: '1' },
            },
          }),
        });
        assert.equal(response.status, 401);
      }
      await denied(
        () => new ConvexHttpClient(active.convexUrl).query(list, {}),
        { kind: 'code', code: 'UNAUTHENTICATED' },
      );
    },
  );
  await check(
    'M7',
    'Another user sees no owner data and cannot change or delete it through MCP.',
    async () => {
      const other = new ConvexHttpClient(active.convexUrl);
      other.setAuth(active.tokens.otherWeb);
      assert.deepEqual(items(await other.query(list, {})), []);
      const second = await connect(active, active.tokens.otherMcp);
      await denied(
        () =>
          second.callTool({
            name: 'work_items_set_status',
            arguments: { id: item.id, status: 'done' },
          }),
        { kind: 'code', code: 'FORBIDDEN' },
      );
      await denied(
        () =>
          second.callTool({
            name: 'work_items_delete',
            arguments: { id: item.id },
          }),
        { kind: 'code', code: 'FORBIDDEN' },
      );
      assert.equal(
        items(await owner.query(list, {})).find((value) => value.id === item.id)
          ?.status,
        'open',
      );
    },
  );
  await check(
    'M8',
    'Invalid status is specifically rejected and the MCP App HTML contains its own JS/CSS.',
    async () => {
      await denied(
        () =>
          mcp.callTool({
            name: 'work_items_set_status',
            arguments: { id: item.id, status: 'unknown' },
          }),
        { kind: 'arguments', tool: 'work_items_set_status', field: 'status' },
      );
      const resource = await mcp.readResource({
        uri: 'ui://foundation/work-items.html',
      });
      const content = resource.contents[0];
      assert.ok(content && 'text' in content);
      assert.equal(content.mimeType, 'text/html;profile=mcp-app');
      selfContainedResource(content.text);
    },
  );
  await check(
    'M9',
    'Owner deletion removes the item in a fresh Convex read.',
    async () => {
      const result = await mcp.callTool({
        name: 'work_items_delete',
        arguments: { id: item.id },
      });
      assert.notEqual(result.isError, true);
      assert.deepEqual(items(await owner.query(list, {})), []);
    },
  );
  report.outcome = 'pass';
} catch (error) {
  report.error = redact(String(error));
  report.outcome = checks.some((result) => result.outcome === 'fail')
    ? 'fail'
    : 'inconclusive';
} finally {
  try {
    for (const client of clients) await client.close();
  } catch (error) {
    report.cleanup = 'failed';
    report.error += `\nClient cleanup: ${redact(String(error))}`;
  }
  try {
    await runtime?.stop();
    if (runtime) {
      assert.equal(
        await access(runtime.privateDirectory).then(
          () => true,
          () => false,
        ),
        false,
      );
      assert.ok(
        runtime.processes.every((process) => process.stopped && process.closed),
      );
    }
  } catch (error) {
    report.cleanup = 'failed';
    report.error += `\nRuntime cleanup: ${redact(String(error))}`;
  }
  if (report.cleanup === 'failed') report.outcome = 'inconclusive';
  await writeFile(
    join(evidence, 'runtime.log'),
    redact(runtime?.logs.join('') ?? report.error),
  );
  report.finishedAt = new Date().toISOString();
  await writeFile(
    join(evidence, 'report.json'),
    JSON.stringify(report, null, 2) + '\n',
  );
}
console.log(JSON.stringify(report, null, 2));
if (report.outcome !== 'pass') process.exitCode = 1;
