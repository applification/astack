# Foundation visual review

The supplied generator created `app/` from the candidate foundation. The existing reference implementation was retained. The design record and MCP-exported `spec.json` were read before judging the UI. `work-items.pen` remained an opaque editable source and was never interpreted through text/file tools.

Source and rendered PNGs were inspected with image tools for these selected frames:

| Frame | Viewport | Source | Rendered observation |
| --- | --- | --- | --- |
| Desktop mixed, `Hhign` | 1040 × 800 | `.astack/design/frames/Hhign.png` | `.proof/design/Hhign-story.png`: matching centered 720 px content, header, horizontal form, filters and open/completed rows. |
| Narrow web, `l5CZRK` | 390 × 800 | `.astack/design/frames/l5CZRK.png` | `.proof/design/l5CZRK-story.png`: matching 24 px outer padding, stacked form, full-width primary action and wrapped row titles; no horizontal overflow. |
| Dark MCP, `mcpFP` | 720 × 520 | `.astack/design/frames/mcpFP.png` | `.proof/design/mcpFP-story.png`: matching compact header, dark semantic palette, status icons, rows and secondary actions. |

The composition, spacing, text, control sizes and semantic colors agree with the selected frames. Small text rasterization/font-metric differences are visible; no material mismatch was identified. Automated observations passed all nine design frames within the original 4 px layout tolerance, with the original exact typography and semantic-surface assertions.

The actual readiness screenshots were also inspected: `../2026-10-05T07-57-09-552Z/web-persisted.png` shows the shared web layout with a persisted completed item; `../2026-10-05T07-57-09-552Z/mcp-app-host.png` shows the remounted MCP resource using deliberate host font/palette overrides. The latter is local host lifecycle evidence, not the default design fixture or installed ChatGPT evidence.

Readiness passed R1–R8 and completed cleanup. Its signed disposable identities establish local authentication and ownership behavior. G1 (live WorkOS sign-in, refresh and organization lifecycle) and G2 (installed ChatGPT OAuth, tool selection and UI behavior) remain skipped.

The first prerequisite doctor found Node 22.14.0 in Bun's inherited PATH while the shell resolved Node 24.21.0. Prefixing PATH with `<HOME>/.nvm/versions/node/v24.21.0/bin` resolved the mismatch without changing project commands. The retained doctor, readiness and final CI runs use Bun 1.4.0 and Node 24.21.0. CI also passed before this environment correction; both logs remain.

All 89 non-Pen reference source/export files compared byte-for-byte equal after generation and verification. The frozen lock, design specification, proof commands, backend authorization/ownership operations, pure domain and portable shared UI were retained. No extra feature was introduced.

Evidence is retained locally under `.proof/`; source remains in `app/`. The trial remains local with no publication or recursive agent delegation.
