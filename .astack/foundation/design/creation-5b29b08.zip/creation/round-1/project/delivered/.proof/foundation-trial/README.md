# Foundation trial result

The supported foundation was created in `app/` with the supplied `candidate/scripts/create-foundation.ts`. The reference implementation was retained without adding a feature. All required local checks passed; live WorkOS and installed ChatGPT remain explicit gaps.

Source revision: `5b29b08aa07b8e22279725b3fe75ca387040a2ec` (see `../../.astack/scaffold.json`). The design and readiness reports identify the generated build as `cb5b4d90c25708610057252fac0b21bbad3f7e56@sha256-685d485791c578fdb1193068ef81045a9b6da80f59fedc6b32ae6f11accee70b`. The former is generator provenance; the latter combines the enclosing checkout revision with the actual generated source identity.

## Commands and results

- `bun install --frozen-lockfile`: passed, Bun 1.4.0; 516 packages installed. The retained lock matches the reference and scaffold digest.
- `bun .codex/skills/astack-work-items/control.ts doctor --json`: initially reported unsupported Node 22.14.0. Selecting the already installed Node 24.21.0 with a command-local PATH produced `ready: true`; see `doctor.json`.
- `bun run check:ci`: passed on the initial PATH and again with Node 24.21.0. Formatting, lint, workspace type checks, 32 tests and browser/Storybook builds passed; see `check-ci.log` and `check-ci-node24.log`. The second run reused Turbo typecheck caches. Build logs retain non-failing chunk-size and dependency directive warnings.
- `bun run design:verify`: passed all nine design-derived Storybook fixtures; see `../design/report.json`, its nine screenshots and `design-verify.log`.
- `bun run readiness -- --evidence .proof/foundation-trial/readiness`: passed R1–R8 on Node 24.21.0; see `readiness/report.json`. This established local target identity, web creation and independent persisted reads, web/MCP status changes, ownership denials, token denials, MCP contracts/resource packaging, local AppBridge lifecycle and absence of uncaught web errors. Cleanup completed.

For Node 24 commands, the selected PATH was `<HOME>/.nvm/versions/node/v24.21.0/bin:$PATH`; no project proof command was changed.

## Visual review

The design record and MCP-exported `spec.json` were read before judging the UI. The opaque editable `work-items.pen` was carried by the generator; it was not interpreted or edited with text/file tools.

The desktop source `Hhign` (1040 × 800) and narrow source `l5CZRK` (390 × 800) were inspected with image tools before implementation review. Every selected source PNG and corresponding fresh rendered screenshot was then visually inspected:

| Frame | State | Observation |
| --- | --- | --- |
| Hhign | Web mixed | Centered 720 px content, heading, form, filters and open/done rows agree with the source. |
| l5CZRK | Web narrow | 24 px page inset, stacked input/action, wrapped titles and visible status actions agree with the source. |
| azIBu | MCP mixed | Compact 32 px inset, two status rows and no creation form agree with the source. |
| mcpFP | MCP dark | Dark semantic palette and compact layout agree with the source. |
| XSTWb | Web empty | Creation form, filters and centered empty instruction agree with the source. |
| FrMvz | Web loading | Loading notice and existing web composition agree with the source. |
| dcVZh | MCP saving | Saving label and dimmed status controls agree with the source. |
| uJu1t | MCP error | Error notice, unchanged item status and available actions agree with the source. |
| ZZhmK | MCP empty | Assistant-directed empty instruction and compact layout agree with the source. |

No material composition mismatch was observed. Small glyph/rasterization and border differences remain between Pen exports and browser rendering; this is not a pixel-identical comparison. The automated check used its unchanged 4 px tolerance. Fixture screenshots establish rendering, with persistence and authorization established separately by readiness.

The real web and local AppBridge screenshots in `readiness/` were also inspected. The local host intentionally supplies different palette/font variables; its screenshot reflects the updated host styles after remount. `mcp-host-observations.json` retains two mounts, two teardown acknowledgements, four closed owned connections and zero uncaught App errors. It also retains aborted requests and HTTP 405 browser messages; the successful lifecycle check does not mean the browser message list was empty.

## Preservation and limits

`preservation.json` records byte equality with the supplied reference for the frozen lock, script definitions, proof implementations, lint configuration, design record/spec, shared UI/stories, platform adapters and authentication/ownership operations. No design specification or proof command was weakened. Source and evidence remain in this local trial. Nothing was published, pushed, merged or sent to anyone; no recursive delivery trial or evaluator rubric inspection was performed.

- G1 / WorkOS: skipped. Live sign-in, refresh and organization lifecycle require a configured test tenant. Temporary signed local identities establish local authentication boundaries only.
- G2 / ChatGPT: skipped. Installed ChatGPT OAuth, model tool selection and UI behavior were not exercised. The local AppBridge host is separate evidence.
