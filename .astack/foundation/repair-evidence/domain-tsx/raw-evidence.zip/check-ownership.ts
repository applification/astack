import assert from 'node:assert/strict';
import { readFile, writeFile, unlink } from 'node:fs/promises';

const probe = 'packages/domain/src/enforcement-probe.tsx';
const configPath = 'packages/ui/tsconfig.json';
const sentinel = "export const protectedValue = 'preexisting';\n";
const originalConfig = await readFile(configPath);
await writeFile(probe, sentinel, { flag: 'wx' });
try {
  const result = Bun.spawnSync(['bun', 'scripts/enforcement.ts']);
  const output = result.stdout.toString() + result.stderr.toString();
  assert.notEqual(result.exitCode, 0);
  assert.match(output, /Refusing to replace an existing enforcement probe file/);
  assert.equal(await readFile(probe, 'utf8'), sentinel);
  assert.deepEqual(await readFile(configPath), originalConfig);
  assert.equal(await Bun.file('packages/ui/src/enforcement-probe.tsx').exists(), false);
  assert.equal(await Bun.file('packages/domain/src/enforcement-probe.ts').exists(), false);
  console.log(JSON.stringify({
    outcome: 'pass',
    guardedPath: probe,
    preservedExistingProbe: true,
    preservedConfig: true,
    createdOtherProbes: false,
  }, null, 2));
} finally {
  await unlink(probe);
}
